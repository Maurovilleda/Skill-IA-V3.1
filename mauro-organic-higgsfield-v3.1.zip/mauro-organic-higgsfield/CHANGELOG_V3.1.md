# Changelog V3.1 — qué se conservó, qué se adoptó, qué se rechazó

Fecha: 25 de octubre de 2026. V3.1 reemplaza a V2.2 + Content Factory V2 (bases de Mauro) y a V3 (paquete `mauro-organic-higgsfield` 1.0.0).

## Conservado de V2.2 / Content Factory V2 como [HARD] / [DURA]

- Contrato: generación directa en Higgsfield, prompt completo sin placeholders, corrección = prompt nuevo, una línea de recomendación, preguntar si falta ángulo/emoción/movimiento/entorno/resolución/duración, nunca evadir filtros, tope de ~5 intentos, nada no pedido, verificar antes de entregar.
- Regla del brief literal (no inventar, no quitar, comparaciones = efecto).
- Lane A completo (foco total, deep DOF, sin bokeh, ruido ISO, encuadre chueco, estado transitorio, desorden, fallo de exposición en stills UGC) y vocabulario de Lane B prohibido en Lane A y video.
- Lista completa de palabras prohibidas y permitidas; nunca negar grano.
- Nueve bloques en orden; identity lock inmediato al capture event.
- Regla de negación (calidad sí, objeto no; alternativa positiva o encuadre).
- Luz 5.0 para video y showcase: brillante, pareja, como dos paneles fuera de cuadro nunca visibles; 5.1 UGC con fuente nombrada, caída, mezcla de temperatura y fallo de exposición; 5.2 productos que emiten luz (la luz donde aterriza, lista prohibida).
- Bloque anti-blur verbatim y cadena de Constraints verbatim; focal 26/35 mm; dos defectos ópticos y dos artefactos de sensor; cara y producto siempre nítidos.
- Identidad: lock byte-idéntico, referencia siempre adjunta, palabras prohibidas, anclas de identidad en orden, sin seed (3–5 y promover), avatares 4K por producto, menores por referencia sin ficha física en texto.
- Producto: medidas y material reales o NO CONFIRMADOS, partes contadas, "copy it exactly", desgaste en stills UGC, marcas pedidas se quedan, kit excluido no aparece, packaging propio.
- Manos de mujer cuidadas con uñas pintadas y pulsera dorada (default de campaña).
- Entorno del market research, Signature Environment, entornos distintos por tanda, señas concretas de casa americana por cuarto, mínimo tres objetos de desorden en UGC.
- Video: 9:16 en primera línea, 480p explícito, duración exacta o preguntar, UNA toma continua (cortes solo si Mauro los pide), cámara literal (POV, no muy cerca, caras y cuerpo completo, no mostrar el impacto, estructura de revelación), producto centrado en showcase/POV/unboxing, diálogo exacto traducido a inglés americano con reacciones cortas reales, sin música, efectos de edición permitidos y bloqueados, cierre "Phone footage...", referencias etiquetadas, comedia sin daño.
- Stills: 9:16, espacio arriba, nunca texto renderizado, "excessive headroom", una imagen por prompt, 2K; listing 1080×1080 con headline y máximo tres etiquetas; variantes sin texto.
- Replicar referencia: cámara idéntica, fondo/objetos/vestuario/identidad cambiados.
- Content Factory: fórmula en una línea, formatos A (7–10 s) y B (12–18 s) con payoff que respira, reglas técnicas (omni_reference, 480p explícito, declined_preset_id, revisar cuadros), cámara 0.5x a ~1 m en tomas abiertas, máximo tres tipos de toma, una locación, misma ropa, equipo donde se usa de verdad, casting relatable, ropa de la tribu con equipos ficticios, tabla de diálogo, texto en edición con hook arriba y CTA de comentario, **trojan retail con regla legal**, fórmulas por tipo de producto, los 10 patrones, flujo producto nuevo / mapeado, brief de una línea, QA, errores documentados.
- Market research completo (prompt fijo, 11 secciones, Reddit primero, audiencias por poder adquisitivo, hashtags por segmento, .docx en español) antes de cualquier contenido de un producto nuevo.
- Trato: español mexicano directo, sin endulzar.

## Adoptado de V3 como [V3]

- Prioridad de instrucciones (orden actual → hechos del producto → campaña → reglas → ejemplos).
- "Use this prompt exactly" vs "turn my script into a video"; análisis/ideas/prompt no autorizan generar; reutilizar autorización; comunicación breve; nunca afirmar sin evidencia.
- Disciplina de referencias: rol de cada input; una referencia de mood no rediseña el producto; mapa preservar/cambiar/excluir.
- Ilustración de uso ≠ prueba de rendimiento; no inventar testimonios ni disponibilidad.
- Sombras de contacto (coincide con la corrección de octubre de Mauro) y "no shadows across the product" en vez de "zero shadows".
- Gramática de cámara: origen, trayecto, destino, llegada; no encadenar whip pans; no cambiar de lado sin reorientar.
- Mecánica de acción: estado inicial → contacto → fuerza/apoyo → consecuencia → estado final; entregas, aperturas, colocaciones y caídas con estado final; respuesta de materiales; tiempo de preparación y recuperación; simplificar o dividir sin borrar el guion.
- Emoción como comportamiento (estímulo → atención → expresión → acción → recuperación), tabla de emociones, emoción del personaje vs del espectador, tareas para cada persona visible.
- Estados por toma y continuidad explícita.
- Definiciones beat/plano/corte/cuadro; tiempos como intención, se mide el render.
- "No added captions; preserve the physical text" en vez de "no text".
- Tipos de apertura; registrar cuándo aparece, se entiende y se entiende la función del producto.
- Familias de estructura como repertorio para briefs abiertos.
- Presupuesto de acciones y ejemplos aritméticos de duración.
- Tabla interna de dirección por unidad.
- Revisión con veredictos por dimensión (pass/revise/unverified/n.a.), cobertura declarada, formato de defecto, no certificar movimiento ni audio desde cuadros.
- Rechazos: reportar el error real, no inferir frases prohibidas universales de un rechazo, unidad defectuosa mínima.
- Ficha única canónica (sin copias contradictorias); variables de campaña ampliadas (mercado/idioma, intención, mapa de referencias, alcance).
- Ejecución: guardar job IDs, timeout = estado desconocido, fallos pueden cobrar, no repetir el lote por una unidad, estados de job y de proyecto.
- Research puntual por decisión con tabla de hallazgos; etiquetas hecho/observación/preferencia/hipótesis/pendiente; separar defecto, preferencia, hipótesis y resultado medido; métricas separadas en atención, interés y negocio; patrones guardados con formato; no sobreajustar.
- Edición puntual sobre imagen aprobada en vez de regenerar; local edits preservan geometría.

## Rechazado de V3 (y por qué)

- Luz "preferencia": luminarias visibles aceptables, cero exigencia de brillo parejo → se mantiene 5.0 (hoy mismo apareció un panel de luz en una escena y es defecto).
- Quitar los defectos, el ruido, el encuadre chueco y el desorden del Lane A → se mantienen; son lo que hace que una still lea como foto real.
- Reducir el vocabulario prohibido a "evitar relleno de calidad" → se mantiene la lista completa.
- Relajar la regla de negación de objetos → se mantiene.
- Cortes libres cuando "aclaren" → se mantiene una toma continua por default; cortes solo si Mauro los pide.
- Regla de manos solo "donde se elija" → se mantiene como default ON de campaña.
- No forzar casas americanas ni desorden → se mantiene ligado a la variable MERCADO (default Estados Unidos).
- No traducir el diálogo al inglés → se mantiene la traducción a inglés americano (mercado US).
- Prohibir el trojan retail → se mantiene con su regla legal (visual, nunca textual).
- "Nunca añadir desgaste por regla" → se mantiene el desgaste obligatorio solo en stills UGC.
- 4K en imagen "cuando aporte" → se mantiene 2K; 4K solo para avatares y referencias.
- "Elegir la duración más corta y decirla" → se mantiene preguntar.
- Quitar 0.5x y ~1 m → se mantienen como default de toma abierta.
- "No asumir omni_reference ni media_id" → se mantienen como bindings verificados con fecha, re-verificables.
- Formato `agents/openai.yaml` como único host → se mantiene por compatibilidad, pero la persistencia se describe para Claude (memoria por producto) y para disco.

## Nuevo, 25 de octubre de 2026 (bitácora en AI Prompt System §19)

1. Avatar como causa de rechazo en Seedance 2.5: cambiar la imagen, no las marcas (regla).
2. Preset recomendado → `declined_preset_id` (regla validada).
3. Dos locaciones en una generación de 12 s con corte planeado (ruta validada cuando Mauro pide el corte).
4. Equipo de luz en tienda → alternativa positiva y constraint (regla).
5. Producto tamaño juguete en manos del niño → ancla de escala contra el cuerpo (regla).
6. Rebote de LED exagerado → cuantificar radio e intensidad (regla).
7. Caída sin liberación → estado final del objeto y mano vacía (regla).
8. Ángulo de packaging casi frontal en GPT Image 2.5 → escribir grados (hipótesis).
9. Patada de puerta no renderizada → describir contacto del pie y velocidad de la puerta (hipótesis).
10. Avatar desde captura de pantalla → recortar barras del teléfono antes de subir (procedimiento).
