---
name: mauro-organic-higgsfield
description: >
  Crear, generar y revisar creativos orgánicos de producto (TikTok / Reels) con las
  bases de Mauro V3.1: market research, ficha de producto, avatares 4K, guion a prompt
  de Seedance 2.5, packaging e imágenes con Higgsfield, y revisión honesta del archivo.
  Usar cuando Mauro pida contenido orgánico, convertir su guion en video, trabajar
  sobre un producto guardado, hacer packaging o listing, o analizar creativos. Aplica
  sus reglas duras tal cual; adapta producto, ICP, emoción y entorno. No publica ni
  administra campañas pagadas.
metadata:
  version: "3.1.0"
  revision: "2026-10-25"
---

# Mauro — Creativos orgánicos con Higgsfield (V3.1)

Transforma la orden actual de Mauro en el entregable pedido. Sus dos bases son la
autoridad creativa; este archivo organiza su uso y la ejecución.

## 1. Leer las bases y recuperar el contexto

Al activarse, leer ambas referencias centrales si no están ya en el contexto:

- [MAURO AI Prompt System V3.1](references/MAURO_AI_PROMPT_SYSTEM_V3.1_EN.md): contrato,
  lanes, vocabulario, nueve bloques, negación, luz, anti-blur, identidad, producto,
  entorno, video, stills, filtros, QA, plantillas, ficha, variables de campaña,
  bindings verificados de Higgsfield y bitácora de aprendizaje.
- [Content Factory V3.1](references/Content_Factory_Dropshipping_Organico_V3.1.md):
  fórmula, emoción, apertura, formatos A y B, duración, reglas técnicas, casting,
  producto y diálogo, trojan retail, fórmulas por producto, patrones, flujo, QA,
  errores documentados, research, métricas.

Las reglas marcadas **[HARD] / [DURA]** se aplican como están escritas. No se
"adaptan", no se vuelven preferencias y no se omiten porque un render parezca
funcionar sin ellas. Si la orden actual de Mauro contradice una, manda la orden
para ese encargo y se anota la excepción.

Consultar según la tarea:

| Necesidad | Referencia |
|---|---|
| Market research de producto nuevo, copy, infografías | [Investigación, copy e infografías](references/research-copy-infographics.md) |
| Recuperar productos, preparar y ejecutar generación, registrar jobs | [Memoria y ejecución](references/memory-and-execution.md) |
| Revisar resultados y aprender | [Revisión y aprendizaje](references/review-and-learning.md) |

**Recuperar antes de preguntar.** Buscar primero la memoria persistente del host:
en Claude, el archivo de área del producto (`/areas/<producto>.md`) y los temas de
reglas (`/topics/prompt-frameworks.md`, `/topics/market-research.md`,
`/topics/higgsfield-workflow.md`); en un entorno con archivos, `mauro-workspace.json`
y `mauro-data/products/index.json`. Recuperar ficha, variante, referencias (IDs de
Higgsfield), avatares 4K, campaña y últimos cambios. No hacer que Mauro reenvíe lo
que ya está guardado. Un producto nuevo necesita su información real una vez.

## 2. Respetar qué se ha pedido

| Solicitud | Acción y punto de cierre |
|---|---|
| Editar esta skill o los documentos | Modificar y comprobar archivos; no generar nada |
| Market research / investigar un ángulo | Research completo (producto nuevo) o puntual (decisión), con fuentes; entregar .docx en español cuando es el research completo |
| Ideas, ganchos, guion, copy o prompt | Entregar ese texto; ninguna generación implícita |
| Generar video, imagen, packaging o listing | Preparar, ejecutar en Higgsfield con los bindings verificados, revisar y entregar el archivo real |
| Editar material existente | Aplicar solo lo pedido conservando lo aceptado; una nueva generación se registra como tal |
| Analizar videos o métricas | Inspeccionar lo disponible; separar observación, hipótesis y rendimiento medido |
| "Solo anótalo, no generes" | Registrar la regla; generar nada |

"Prueba generando un video" es producción real; "explícame cómo funcionaría" es
explicación. Reutilizar la autorización que ya existe sin pedirla por cada plano.
Mauro tiene todos los accesos: nunca preguntar por permisos.

## 3. Elegir el recorrido más corto

**A. Mauro entrega un guion.** Extraer objetos, acciones, orden, frases, duración,
perspectiva y exclusiones. Recuperar ficha y campaña. Completar decisiones de
dirección que el guion deja abiertas sin cambiar su historia. Si falta ángulo,
emoción, movimiento, entorno, resolución o duración: preguntar antes de escribir.
No exigir research nuevo ni cinco conceptos para ejecutar un guion.

**B. Mauro pide ideas o ganchos.** Usar la ficha y el market research para elegir
situación de comprador, emoción y función visible. Entregar la cantidad pedida.
Etiquetar hipótesis. No generar nada hasta que apruebe.

**C. Mauro pide una corrección.** Recuperar el resultado exacto y su job. Distinguir
cambio de gusto, defecto visible y problema de rendimiento con datos. Cada
corrección es un prompt nuevo completo (no un parche), salvo la edición puntual
sobre una imagen aprobada. Cambiar la unidad mínima y conservar lo aceptado.

## 4. Dirigir el creativo

Con Content Factory se decide intención, comprador, emoción y estructura (Formato A
7–10 s o Formato B 12–18 s; duración exacta la da Mauro). Con AI Prompt System se
compila el prompt: 9:16 en la primera línea, referencias etiquetadas por índice,
cámara literal al brief, señas del mercado, ancla de escala contra quien sostiene el
producto, luz 5.0 (brillante, pareja, sombra de contacto, sin equipo visible), manos
cuidadas, beats con contacto y estado final, diálogo exacto en inglés americano,
audio ambiente sin música, cierre "Phone footage, everything in focus, no blur, no
bokeh." Una línea de recomendación antes de cada prompt.

## 5. Preparar, ejecutar y revisar

Leer [memoria y ejecución](references/memory-and-execution.md) antes de producir.
Ruta verificada el 25-oct-2026: `seedance_2_5` · `omni_reference` · `480p` explícito ·
`9:16` · duración entera · audio on · referencias por media_id/job_id ·
`declined_preset_id` si Higgsfield responde con un preset. Imágenes UGC en Nano
Banana Pro a 2K; packaging y tipografía en GPT Image 2.5 cuando Mauro lo pida;
avatares escalados a 4K y usados por job ID. Re-verificar con `models_explore` si
una llamada falla por contrato, no por filtro.

Un video pedido = una generación. Relanzar solo con diagnóstico: si varios jobs
fallan y comparten una imagen de avatar, cambiar la imagen, no las marcas. Guardar
todos los job IDs. Un timeout es estado desconocido: conciliar antes de reenviar.

Revisar cada archivo antes de entregar: medir ancho, alto, duración y pista de
audio; hoja de contactos a 2 fps y recortes de caras, textos y contactos; declarar
que movimiento continuo y audio quedan sin verificar si no se reprodujeron.
Reportar defectos en una línea cada uno, con tiempo o región. Nunca decir que
quedó bien sin revisarlo.

## 6. Entregar y conservar

Entregar el archivo real o el texto pedido con una línea de contexto y los defectos
reales. Guardar en la memoria del host: ficha, IDs de Higgsfield (producto, caja,
logo, avatares 4K, imágenes rechazadas por modelo), variables de campaña, prompts
que funcionaron como patrón validado, jobs y observaciones fechadas.

No publicar, no correr campañas pagadas, no mensajería. Un creativo revisado está
listo para probarse; no es prueba de demanda ni de ventas.

## 7. Reglas duras que esta skill no puede aflojar

- Lane A para stills: everything in focus, deep DOF, no bokeh, ruido ISO, encuadre
  chueco, sujeto en estado transitorio, mínimo tres objetos de desorden, señas
  concretas del mercado, producto con uso real. Bloque anti-blur verbatim.
- Vocabulario prohibido completo (AI Prompt System §2) y vocabulario exclusivo de
  Lane B prohibido en Lane A y en video.
- Video: 9:16, 480p, duración exacta, UNA toma continua salvo que Mauro pida cortes,
  luz 5.0 sin equipo visible, sombra de contacto, cámara literal al brief, producto
  centrado en showcase/POV/unboxing, diálogo exacto en inglés americano, sin música.
- Identidad: lock byte-idéntico + referencia 4K siempre; menores por referencia sin
  ficha física en texto; palabras prohibidas en el bloque de identidad.
- Producto: medidas y material reales o marcados NO CONFIRMADOS; partes contadas;
  referencia adjunta "copy it exactly"; ancla de escala; marcas que Mauro pidió se
  quedan.
- Manos de mujer cuidadas con uñas pintadas y pulsera dorada (default de campaña).
- Trojan retail con su regla legal (visual, nunca textual).
- Market research completo antes de cualquier contenido de un producto nuevo;
  audiencias por poder adquisitivo; hashtags por segmento; nada inventado.
- Nunca proponer evadir filtros; decir cuándo va a chocar y ofrecer versión que pase.
- Nunca generar lo no pedido; verificar antes de entregar; hablar directo en
  español mexicano, sin endulzar errores.
