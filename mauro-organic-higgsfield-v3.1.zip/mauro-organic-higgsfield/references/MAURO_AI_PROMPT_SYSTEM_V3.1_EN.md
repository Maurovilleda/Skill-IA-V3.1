# MAURO AI PROMPT SYSTEM — V3.1

**Production standard for writing and executing image and video prompts for organic short-form creative (TikTok / Reels), store listings and packaging.**

Revision: 25 October 2026. **Supersedes V2.2 and V3 in full.** Keep both as archives.

**How to read this document.** Every rule carries one of three tags:

- **[HARD]** — a rule Mauro validated in production (V2.2 + Content Factory V2 + corrections of September–October 2026). It is not a preference and it is not "adaptive". It is applied as written in every prompt unless Mauro's current explicit request says otherwise for that single job.
- **[V3]** — a method adopted from the V3 package because it adds something the hard rules did not cover (instruction priority, reference discipline, action mechanics, emotion arcs, review verdicts, cost ledger).
- **[NEW]** — an observation from the KickSprout session of 25 October 2026, dated, labeled as observation or rule.

**Companion:** Content Factory — Dropshipping Orgánico V3.1 (Spanish). Content Factory owns buyer context, emotion, narrative structure, timing, the product sheet and learning. This document owns prompt compilation, visual direction, physical action, continuity, execution and output review. When the two conflict, this document wins on light, camera, takes and framing; Content Factory wins on story, emotion and timing.

**What V3.1 fixes from V3.** V3 turned the hard rules into "preferences" (lights visible or not, shadows or not, one take or cuts, defects or no defects, hands rule only when selected, American markers optional, no translation to English, no trojan retail). Those rules exist because the opposite produced plastic skin, studio-looking rooms, visible light panels, broken faces across cuts and rejected jobs. V3.1 keeps them as [HARD] and takes from V3 only the parts that make execution safer and prompts more precise.

---

## 0. OPERATING CONTRACT

### 0.0 Instruction priority [V3]

Within the host's rules, apply in this order: **Mauro's current explicit request → confirmed product facts and protected references → the approved campaign variables (Section 17) → the [HARD] rules of this document and Content Factory → [V3] methods → examples, references and research.** A creative request cannot make an unsupported product feature true: say so and offer a faithful alternative.

### 0.1 Contract [HARD]

- The assistant **generates** images and video through Higgsfield and fires the job once the prompt is ready. If generation is unavailable, it delivers the complete prompt so Mauro can run it.
- Every prompt is **complete and final**: never a fragment, never a placeholder such as `[paste lock here]`. Verbatim blocks are expanded inline before delivery.
- Every correction produces a **complete new prompt**, not a patch. Sole exception: a targeted edit on an already-approved image.
- **One line** of recommendation before each prompt. One line, not a paragraph.
- **Quantity:** a video request is exactly that many videos, one generation each, no doubles. A failed or rejected job may be relaunched once the cause is diagnosed; it is not a second variant. Image prompt batches follow Mauro's number; if none is given, minimum 10 per batch; 5 is acceptable when replicating a single reference image.
- If angle, emotion, movement, environment, resolution or duration are unclear: **ask before writing.** Ask only for what materially affects product truth, the required action, identity, feasibility or cost; ordinary directing choices are made inside the brief without a questionnaire. [V3]
- If a prompt will collide with a content filter: say so and offer a version that passes. **Never propose circumventing a filter.** If a job comes back blocked, report it plainly and say exactly what changed in the version that passed.
- If roughly five attempts fail on the same shot: stop, say so, and propose another angle or reference instead of burning credits. Every retry needs a diagnosis; there is no free retry allowance. [V3]
- **Never generate anything Mauro did not ask for.** No extra logos, variants, bonus clips, alternative versions or "improvements". Analysis, ideas, skill editing and prompt-only requests do not authorize generation; "try generating one" is real production. [V3]
- When Mauro says **"just note it, don't generate yet"**: record the rule and generate nothing.
- Reuse the authorization that already exists; do not ask again for each shot inside an authorized plan. Mauro has all accesses: never ask for permissions. [V3]
- **Verify the output before delivering:** resolution, aspect ratio, duration, and frames of every video. Flag any missing element. Never claim a generation, a review, a retention result or a sale without evidence. [V3]
- Keep communication brief, in Mexican Spanish, direct, no sweetening of errors. Do not expose routine planning as an approval stage. [V3]

### 0.2 Faithful-brief rule [HARD, refined by V3]

- **Do not invent.** Colors, variants, settings, characters, props, story beats and dialogue come from the brief only.
- **Do not drop.** Every element Mauro lists appears in the prompt, in his order. Check the brief line by line before submitting; a missing bag, sticker or prop is an error.
- **Do not reinterpret comparisons.** "Light as if there were softboxes" is an effect, never equipment in frame. "Not too close" is not macro. "Do not show the impact" does not authorize showing it between sampled frames.
- Two different requests: **"use this prompt exactly"** means preserve wording, add nothing, improve nothing. **"Turn my script into a video"** means preserve meaning and order while specifying shots, contacts, timing and light. Propose a story change only when asked for improvement or when the brief cannot be executed clearly as written. [V3]

---

## 1. MODES AND THE TWO LANES

The lanes govern **still images** and are mutually exclusive. Video is governed by Section 10. Store/listing images by Section 11.1.

### Lane A — ORGANIC / UGC still [HARD]

The default for every short-form still creative. Lane A always requests: `everything in focus` · `deep depth of field` · `no bokeh` · `no blur` · phone perspective, slightly wide · clipped highlights, crushed shadows · mixed color temperature · sensor noise · crooked, off-center framing · unposed subject caught in a transitional state.

### Lane B — CINEMATIC [HARD]

Only on explicit request. Vocabulary exclusive to Lane B and **banned in Lane A and in video**: `shallow depth of field` · `bokeh` · `cinematic depth` · `motion blur` (as a sought effect) · `natural inertia` · `environmental interaction` · `proper weight distribution` · `natural hand coordination` · `subtle body adjustments` · `realistic body mechanics` · `follow-through motion` · `natural acceleration` · `natural deceleration`.

**How this coexists with the action mechanics of 10.11 [V3]:** the words above are banned as words. The physics they point to is written as observable action in plain sentences ("she lets go of the box only after his two hands are under it", "the ball rolls out of the right arch and stops at his left foot"). Never as jargon.

### Video (Section 10) and Store/listing (Section 11.1)

Showcase lighting (5.0), centered product framing (10.4), clean new product. Lane A clutter, defects and crooked framing do not leak into these modes.

---

## 2. VOCABULARY [HARD]

### 2.1 Permanently banned

`ultra realistic` · `hyperrealistic` · `photorealistic masterpiece` · `8k` · `16k` · `4k` **as a quality word inside the prompt** (valid only as an output parameter) · `masterpiece` · `best quality` · `high quality` · `award winning` · `hyper detailed` · `trending` · `epic` · `perfect quality` · `stunning` · `beautiful` · `gorgeous` · `flawless skin` · `smooth skin` · `porcelain skin` · `perfect complexion` · `radiant` · `glowing skin` · `octane render` · `unreal engine` · `professional photography` · `studio lighting` · `softbox` · `rim light` · `cinematic` (in Lane A and in video) · `golden hour` · `magic hour` · `warm cinematic lighting` · `dramatic lighting`

`softbox` stays banned as a word. Showcase light is written as *"as if two large soft light panels were placed just out of frame on the left and right; the lights themselves are never visible."*

**Specific warnings:** `flawless skin` and `smooth skin` are the direct cause of plastic skin. `golden hour` reads as an AI signature. `Portra 400` and `Cinestill 800T` are over-prompted; if a film stock is needed use Kodak Gold 200, Ektachrome or Ilford HP5, or none in phone photography. **Never pair `film grain` with a phone photo**: use `ISO sensor noise, luminance plus chroma`.

### 2.2 Permitted

`photorealistic` · `real photograph` · `taken on a real camera` · `iPhone photo` · `phone photo` · `phone footage`

### 2.3 Never negate grain or noise

They are wanted in realism prompts.

### 2.4 Text negation when a label must stay [V3]

Never write a bare `no text` on a product whose label or packaging print must remain. Write: *"no added captions, letters or graphic overlays; preserve the physical text printed on the product and box exactly."*

---

## 3. THE NINE BLOCKS — MANDATORY ORDER (STILLS) [HARD]

Narrative sentences, never keyword lists.

| # | Block | Contents |
|---|---|---|
| 1 | **Capture event** | Who took the photo and why. One concrete sentence. |
| 2 | **Identity lock** | Pasted byte-identical. Never paraphrased. |
| 3 | **Action and expression** | A transitional state, never a pose. |
| 4 | **Product lock** | Pasted byte-identical. Real dimensions, material, parts counted. |
| 5 | **Environment** | Lived-in, concrete regional markers, at least three clutter items (Lane A). |
| 6 | **Light physics** | Section 5. |
| 7 | **Optics and sensor** | Section 6. The anti-blur block is mandatory. |
| 8 | **Framing** | 9:16, clear space at the top for overlay. |
| 9 | **`Constraints:`** | Labeled, last, always. |

The identity lock goes **immediately after** the capture event. Burying it mid-prompt causes face drift. In store/listing images a block that does not apply (identity, clutter) is omitted; it is never filled with an invented person or object. [V3]

---

## 4. THE NEGATION RULE [HARD]

- Negating a **quality or process** works: `no blur`, `no bokeh`, `no studio lighting`, `no shadows across the product`.
- Negating an **object** fails: asking for "no elephant" produces an elephant.

Exactly two ways to remove an object: **replace it with its positive alternative** (*"a plain empty painted wall, smooth and unbroken, nothing hanging on it and nothing in front of it"*) or **frame it out** by describing a framing where it cannot fit. Object negation may also sit in `Constraints:` as a safety net, never as the primary method. Keep `Constraints:` short and scene-specific; positive description carries the scene. [V3]

---

## 5. LIGHT

### 5.0 Showcase lighting — ALL VIDEO and every product-focused shot [HARD]

Overrides 5.1 for all video and any shot whose job is to show the product.

- **Never dark, never dim.** The scene is very bright. Household lamps and ceiling lights are on; they may exist in frame as objects of the room.
- Light is **clean and even**, as if two large soft light panels were placed just out of frame on the left and right. **The light equipment itself is never visible**: no panels, no stands, no umbrellas, no ring lights, not in homes and not in stores. [NEW 25-oct: a bright rectangular light panel appeared at the edge of a Target reveal scene; add the positive alternative "the only lights in the store are its own ceiling fixtures" and the constraint `no light stands, no light panels, no photo equipment in frame`.]
- **Shadows (rule of October 2026):** always a soft contact shadow under the product and micro-shadows of texture in fabric, plush, leather or relief, so the product reads as supported and material. **No cast shadow** from a hand, a person, a lid, a box or any object may fall **across** the product or a face. "Zero shadows anywhere" is wrong: it flattens the object. [HARD, aligned with V3 §5]
- Faces and product show every detail: features, textures, stitching, print and colors read clearly. The light sells quality.
- Write it as: *"Lighting is very bright, clean and even, as if two large soft light panels were placed on the left and right sides just out of frame; [subjects] lit evenly from both sides, a soft contact shadow under the product, no shadows across the product or faces, every detail sharp and clear; the lights themselves are never visible."*
- Constraints: `no dark areas, no shadows across the product, no light stands or panels in frame`.
- When light must come from one side, place it in front of or above the product, never behind it.

### 5.1 UGC realism lighting — still lifestyle and review photos only [HARD]

1. **One** key source per subject, named, never generic. 2. Its **direction**. 3. Its **falloff**: which side darkens and how fast. 4. Whether there is fill (usually **not**). 5. **Color temperature including the mismatch**: warm against cool, always clashing. 6. **At least one exposure failure**: a blown window, a white-balance error, a clipped highlight.

Face and product stay well lit and fully readable; the darkness goes into the room. Within one batch every image differs completely: light, weather, hour (gray overcast, rain, dark morning, low sun through blinds, night with lamps only), camera quality and location. Never all sunny. **Direct on-camera flash** is the strongest realism lever when the shot permits it.

### 5.2 Light-emitting products [HARD]

Projectors, lamps, LED strips and bulbs, candles, headlights, RGB, screens, neon, tree lights, flashlights, glow-in-the-dark, lit aquariums, LED scoreboards.

**Describe light where it lands, never while it travels.** Permanently banned: `visible beam` · `light shaft` · `cone of light` · `beam cutting through` · `veiling glare` · `milky haze` · `bloom halo` · `atmospheric glow` · `volumetric light` · `god rays` · `light rays` · `glowing aura` · `light spilling into the air` · `hazy light` · `dusty light`. Describe the receiving surface: what the light lands on, how, what it clips, what it clashes with. When a product must read as on with the source out of frame, the bounce on nearby surfaces is enough.

[NEW 25-oct] Quantify the bounce: *"a faint red reflection on the rug within about 10 cm of the panel"*. An unquantified "red light on the rug" rendered as a large red stain across the floor. Use the LIGHT BEHAVIOR LOCK of the product sheet verbatim.

---

## 6. OPTICS AND SENSOR — MANDATORY ANTI-BLUR BLOCK [HARD]

Every Lane A image prompt closes Block 7 with this text verbatim:

```
Photographed on a phone, everything in focus, deep depth of field, no bokeh,
slight lens distortion at the frame edges, fine ISO sensor noise with luminance
and chroma in the shadows, [one localized motion cue].
```

`Constraints:` always closes with this string verbatim:

```
no blur, no bokeh, no shallow depth of field, no haze, no fog, no smoke,
no atmospheric glow, no light beam, no studio lighting
```

The localized motion cue is one named, located thing (*"one hand slightly smeared where it moved"*). Never `motion blur` alone, never on the whole frame. Block 7 also carries a 26 mm or 35 mm equivalent focal length, at least **two** localized optical defects and at least **two** sensor artifacts. Of the four blur types only two are allowed: localized motion blur, and noise-reduction smearing in shadows only, always with "while edges stay sharp". **Face and product are always sharp.**

Every video prompt closes with: *"Phone footage, everything in focus, no blur, no bokeh."*

---

## 7. IDENTITY AND REFERENCES

### 7.1 Identity [HARD]

- Casting region and recurring characters are **campaign variables** (Section 17), declared once and held constant.
- The identity lock is **pasted byte-identical**. Paraphrasing causes face drift.
- When a recurring avatar exists as an image, **attach the avatar reference in every generation where she appears** and write *"keep her face and hair exactly"*.
- **Banned inside the identity block:** `beautiful`, `attractive`, `striking`, `average-looking` (documented placebo).
- What anchors identity, strongest first: a unique located marker (mole with distance and side) → a named asymmetry → hair as four facts (length, texture, color, part) → eye color and brow shape → skin tone plus one texture fact → facial geometry → age as an exact number → one characteristic object.
- **There is no seed.** Consistency = frozen byte-identical block + reference image + generate 3 to 5 + cull + promote the best to the new reference. Avatars are stored upscaled to 4K (Higgsfield upscale) and the 4K job is the reference, never the raw upload.
- **Minors:** a child's face may be fully visible, well lit, sharp, close to the lens and looking at camera. The text **never** carries a granular physical spec of a minor (mole coordinates, lip shape, skin texture, facial geometry). The child is supplied through a reference image; the text carries only approximate age, wardrobe, action, expression, eye direction and position in frame. Clothing is ordinary and full-coverage; underwear, swimwear or partial dress is a known rejection cause.

### 7.2 Reference discipline [V3]

- For each input record its **role**: product identity, packaging, person/wardrobe, location geometry, composition, movement, lighting or audio. A mood reference never redesigns the product. A camera reference never imports its actors, brands or props.
- For a reference-driven revision make a **preserve / change / exclude** map before writing. Follow Mauro's changes first, then copy the reference.
- Attach only the references the visible scene needs. Label each one by index in the prompt (*"Reference image 1 is the boy, keep his face and hair exactly. Reference image 2 is the box, copy its printed design exactly."*).
- If a reference shows only one side, do not invent hidden mechanisms as verified facts.

### 7.3 Avatar rejection protocol [NEW 25-oct, rule]

If several jobs in a batch fail and the only element they share is one avatar reference image, the image is the cause. Swap that avatar for another approved image (upload → upscale 4K → use the 4K job) and relaunch the same prompts unchanged. **Do not strip the brands, props or dialogue to "make it pass"**: on 25 October 2026 the prompts containing PS5 DualSense, Target bullseye signage, a Starbucks cup and a McDonald's cone all passed Seedance 2.5 once the avatar was swapped (4 of 4). Record the rejected image ID in the product sheet so it is never reused on that model.

---

## 8. PRODUCT

### 8.1 Product truth [HARD]

- **Real dimensions and material**, from product photos or the supplier sheet. Never invented. Unconfirmed → flagged "NOT CONFIRMED" and requested.
- **Count every part explicitly:** "exactly two side arches", "exactly three red arrows", "exactly one yellow center target". Applies to buttons, straps, wheels, legs, zippers, ports, seams, ears, wings, lights.
- **Always attach the approved product reference** and write *"copy it exactly"*. Never change colors, pattern, shape or variant.
- Kit items Mauro excludes (battery, cable, charger) do not appear.
- **UGC stills:** the product reads **used, not rendered**: a fingerprint on a glossy surface, a scuff at the base, a mold parting line, some dust. **Showcase video, listing and packaging:** clean, new, premium. (V3's "never add wear by rule" is rejected; wear is mandatory in Lane A stills only.)
- Do **not** remove incidental brands that Mauro wrote into the brief (mugs, clothing, cars, phones, stores, controllers). They stay as he asked.

### 8.2 Scale anchor [HARD, sharpened NEW 25-oct]

Every prompt states real size, a comparison object and where the product goes and where it **never** goes. When a person **holds** the product, the anchor is written against that person's body: *"80.5 cm wide, as wide as the boy's shoulders and both arms spread, knee-high to him"*. Without it the model shrinks the product to toy size in the hands (observed in video 4, 25-oct). Avoid wide-angle distortion that enlarges a small product misleadingly. [V3]

### 8.3 Illustration, not proof [V3]

A generated demonstration shows supported use; it cannot prove durability, heat, waterproofing, capacity or results. Never invent testimonials, reviews, retailer availability or endorsements through pictures. (Trojan retail — Content Factory §9 — is a visual discovery device with its own legal rule; it is not a claim of availability.)

### 8.4 Hands rule [HARD, campaign default ON]

Every video and image where a woman's hands appear: *"clean, feminine, manicured hands with glossy painted nails and a gold luxury bracelet on her wrist."* Never dirty, bare-nailed, rough or deformed. Covers POV shots where the hands are the protagonist. It is the default value of the HANDS & JEWELRY campaign variable; Mauro can switch it off per campaign.

### 8.5 Packaging [HARD]

Use Mauro's own packaging reference whenever the box appears and copy it exactly. In showcase and unboxing video the box is clean and premium; in UGC stills it is never impeccable (dented corner, shipping crease, torn plastic). Show every packaging layer he names, in his order. Record what the box actually contains in a given story (assembled product vs loose parts) because the brief decides, not a default.

---

## 9. ENVIRONMENT AND CONTINUITY

### 9.1 Environment [HARD]

- Backgrounds and tone come from **that product's market research**: its environments, niche and ICP. Never a generic room.
- If the campaign has a **Signature Environment** (Section 17), it is the default video background unless Mauro names another location.
- Within a batch, environments **differ** (identity repeats, the room never) unless Mauro specifies the signature setting.
- **Concrete regional markers are mandatory.** "American home / kitchen / garage" alone returns a generic render. The MARKET campaign variable decides which marker set applies; the default market is the United States and its markers are listed in 9.2. (V3's "do not force American homes" is rejected: Mauro sells in the US; the markers are scoped by MARKET, not removed.)
- **UGC stills:** at least **three** real clutter items (unopened mail, a half-crushed Amazon box, keys on the counter, a charging cable across the counter, an overloaded power strip, a laundry basket, scuffed baseboard, a crooked frame, a bent blind slat, sneakers by the door). **Showcase video:** lived-in but tidy; nothing competes with the product.
- Season visible when it justifies the purchase (string lights, tree, snow in the window) — from the campaign, not by default.

### 9.2 Markers valid in any American room [HARD]

120 V outlets with two vertical slots and a round ground pin · flat toggle switches · drywall with baseboard · double-hung windows with white frames · four- or six-panel doors with round knobs · a wall thermostat · a ceiling smoke detector.

**Kitchen:** large stainless refrigerator with ice dispenser · microwave above the range · built-in dishwasher · double sink with high-neck faucet · shaker cabinets · subway tile · island with stools. **Bedroom:** wall-to-wall carpet · sliding or louvered closet doors · ceiling fan with light · nightstand with power strip · roller shade or blinds. **Bathroom:** tub-shower combo with curtain on a curved rod · mirrored medicine cabinet · exhaust fan · small white tile. **Living room:** large sectional · wall-mounted TV · rug over carpet · fireplace with mantel · picture window · framed family photos. **Garage:** sectional door with opener · LED tubes · oil-stained concrete · workbench with pegboard · wheeled bins. **Exterior:** deck · wood plank fence · coiled hose · covered grill · mailbox on a post · vinyl siding. **Car interior:** steering-wheel controls · cup in the cup holder · charger in the 12 V port · rubber floor mats. **Retail store:** bright ceiling fixtures · clothing racks · display tables · polished floor · the store's own signage when the campaign names the store.

### 9.3 Continuity state [V3]

For each shot track: product state (closed/open/assembled/on), position, orientation, which hand holds what, wardrobe, relevant props, time of day and light. The next shot starts from that state or explicitly establishes the change. One coherent situation per shot. One location per video (two at most when the story demands it and Mauro asked for the cut).

---

## 10. VIDEO

### 10.1 Format [HARD]

- **9:16 vertical, always.** First line of the prompt: *"Vertical 9:16 phone video"*. Pass `aspect_ratio: 9:16` as a parameter too.
- **480p, always**, as an explicit resolution parameter (width and height alone are ignored and the job comes back at 720p). Never 1080p. Mauro upscales on his side.
- **Duration is exactly what Mauro states**, whole seconds. If none is stated, **ask**. (V3's "pick the shortest and state it" is rejected.)
- Before delivery check every file: 9:16 at 480p (measured 480×854 on Seedance 2.5 on 25-oct; accept the model's documented rounding of 9:16, never 720p), the exact duration, audio track present, all requested beats present. [V3: measure, do not assume]

### 10.2 One continuous take [HARD]

- A video request is **one video in one continuous take**, written as *"one single continuous take, no cuts."* Camera moves (pan, whip, zoom, follow) happen inside the take. Never split into clips, parts or a multi-shot sequence; never stitch generations silently.
- **Cuts only when Mauro asks for them** ("en otro clip", "corte a"). Then two routes, Mauro's choice: (a) one generation with the planned hard cut written in ("two scenes joined by one hard cut at 6 seconds, no other cuts") — validated 25-oct with a 12 s, two-location video; or (b) separate units of 2–5 s with the same references, assembled in editing (Content Factory rule: a single long generation with five separate moments degrades). Unassembled clips are partial work when a finished video was requested. [V3]
- Beats are written in the exact order Mauro gives them, as one flowing action.

### 10.3 Camera follows the brief literally [HARD, grammar from V3]

- **POV** means first person from the subject's own eyes: only her hands, body or lap appear; never a third-person view of her. Whatever she looks at sits in front of her in frame.
- **"Not too close"** is a medium distance where action and context both read. Never macro.
- **"Faces and full body visible"** means a front or front three-quarter angle, head to toe. Never from behind unless asked.
- If Mauro says a moment is **not shown** (an impact, a throw, a crash), it is not shown; the camera pans away and reveals only the aftermath he describes.
- Reveal structure for gags: reaction → gesture (point, shout) → the camera pans to where she points → the aftermath, held long enough to read.
- Open shots: phone propped or on a tripod, locked, slightly wide (0.5x) at about 1 m height, full body, slight edge distortion. Handheld movement **only** in POV or when the operator walks for a reason. Never "slight handheld shake" on a whole video.
- Every camera move needs an origin, a path, a destination and a readable arrival; a pointing gesture motivates a pan. Do not chain pushes, spins or whip pans to simulate energy. Do not switch sides of an interaction without reorienting the viewer. [V3]
- Maximum three shot types per video: locked wide · POV hands · product close-up.

### 10.4 Centered product framing — showcase, unboxing and POV [HARD]

All the action stays in the exact center of the frame; hands bring the product forward to the center of the lens and hold it there, centered and readable. This overrides the Lane A off-center rule for these shots.

### 10.5 Lighting [HARD]

Section 5.0 applies to every video: bright, even, every household light on, contact shadow under the product, no shadows across product or faces, no light equipment in frame. **No dark or dim video, ever.** The Lane A exposure failures and crushed shadows do not apply to video.

### 10.6 Dialogue [HARD]

- Lines Mauro dictates are spoken **exactly** as given, at the moment he specifies, by the speaker he names. When he writes them in Spanish they are translated into natural American English (the market is the US); the meaning and order are preserved word for word. (V3's "never translate" is rejected.)
- Reactions use short, real American English: "babe", "oh shit", "holy shit", "no way", "wtf", "let's go", "shut up!", "yo, LOOK!", "that's sick!", "thank you!". No corporate voiceover, no long sentences. A line is inserted only when the brief calls for a reaction; a silent beat stays silent. [V3]
- "Fuck" written out is a near-certain rejection; slurs never.
- When Mauro specifies a voice quality ("very feminine voice", "New York accent"), write it in.

### 10.7 Audio [HARD]

**No music, no soundtrack.** Natural ambient sound and dialogue only; name the specific contact sounds (lid lifting, cardboard, plastic parts clicking, a box landing in hands). ASMR requests: name each sound, no voice, slow deliberate hands.

### 10.8 Allowed and blocked in video [HARD]

- **Editing effects allowed:** speed ramp, zoom punch, camera shake, whip pan, frame rotation, mirror, multi-exposure clone, hard cut (only when Mauro asks for cuts).
- **Blocked inside the take:** shallow depth of field, bokeh, rack focus, full-frame motion blur, bloom or white atmospheric flash, haze, fog, smoke. Out of the vocabulary: cinematic, golden hour, epic.
- Motion blur in video is localized and named, as in stills.
- Close every video prompt with: *"Phone footage, everything in focus, no blur, no bokeh."*

### 10.9 References in video [HARD]

Attach the avatar image(s), the product image and the packaging image the scene uses. Label each by index with its narrow role. With references attached the prompt is **short and directive**; a very long prompt on top of references is a documented error.

### 10.10 Comedy and slapstick [HARD]

Exaggerated physical comedy is written as comedy: people end **unhurt and comically dazed**. When a beat is likely to be filtered (flames on a body part), move the effect onto the object next to it and tell Mauro exactly what changed. Define the intended trajectory and aftermath of a throw, fall or drop; do not invent harm or change the gag silently. [V3]

### 10.11 Action mechanics and material response [V3]

For each important action resolve: **initial state → approach/contact → force or support → visible consequence → final state.** Write only the contacts this scene needs; no physics manual in every prompt.

- Which hand holds, which manipulates, what supports the object, where it goes, when it is released.
- A **handover** ends after the receiver bears the weight and the giver lets go. An **opening** ends with the actual accessible contents, not a floating lid. A **placement** ends supported and settled. A **throw or drop** ends with the object at a stated resting place, and the hand that held it is now empty. [NEW 25-oct: an ice cream cone rendered both on the floor and still in the hand because the release was not stated; write *"the cone leaves his hand and lands on the floor; his hand is empty from then on"*.]
- Materials respond as in real evidence: rigid keeps shape, flexible bends at plausible points, fabric folds, foam compresses and recovers, a foam ball rolls low and stops.
- Respect preparation and recovery time; do not make every action equally slow, interpolate a person like a board, or demand simultaneous operations with the same hand.
- If one generation is overloaded, name the difficult interaction and simplify it or split at a legitimate boundary **while preserving the script**; if that changes an explicit requirement, resolve it with Mauro before generating.

### 10.12 Emotion as visible behavior [V3, bounded by HARD]

Content Factory chooses the intended emotion. Translate it into behavior: **trigger → attention shift → expression/body response → action → recovery or change.** Drama lives in the hook; the rest are credible reactions (a side smile, an "oh", a thumbs up, a laugh). A reaction to discovering a product differs from the reaction after using it. Do not hold a fixed mask of surprise through every event unless Mauro's brief asks for it (then it is his call, e.g. "stunned from the very first frame"). Give every visible person a task and a target of attention; secondary people do not all gesture at the camera.

### 10.13 Structures [HARD, repertoire from V3]

Content Factory's two validated containers remain: **Format A** (7–10 s, stable hook + detail cuts, within one take unless Mauro asks for cuts) and **Format B** (12–18 s, five beats, the ambient payoff breathing for almost half the video). V3's structure families (demonstration, problem-and-use, discovery, unboxing, gift, humor, transformation, ritual, sensory) are a repertoire for open briefs; they never replace a story Mauro wrote.

---

## 11. FRAMING AND OUTPUT (STILLS) [HARD]

- **9:16 always** for TikTok and Reels creative, declared on the first line. Extend the real background when needed; never distort the product.
- Clear space at the top for overlay text; **never render text** inside creative images. Request "excessive headroom" when overlay room is needed; never "cropped forehead" (incompatible).
- UGC stills: imperfect, off-center framing. Product showcase: centered (10.4).
- **One image per prompt**, count 1. Never two variants of the same shot.
- Output **2K** as a parameter (rule of October 2026), never as a word. 4K is used only for upscaling avatars and reference images.

### 11.1 Listing images, infographics, packaging and variant images

- Listings and infographics: **1080×1080**, brand palette, minimal text (a short headline and at most three short labels), never cut off, overflowing or misspelled; check every word after rendering. Every requested row or element present. Each infographic in a set clearly different in layout, angle and focal element.
- Packaging packshots: the format Mauro states (25-oct: 1:1 at 2K on GPT Image 2.5 Sunburst, quality high); logo reference attached and "copy it exactly"; product reference attached; one box only. [NEW observation: "front three-quarter" rendered nearly frontal; write the angle in degrees and name the side panel that must read.]
- When an image is attached only as a guide: *"Reference image N is ONLY a guide for [pattern/colors]. Do not paste or collage it into the image."*
- Variant images (one per color/design) carry no text unless asked; simple natural poses; deformed anatomy means regenerate.
- Mockups exclude any kit item Mauro says to leave out.
- **Local edits** on an approved image preserve geometry, identity, composition and light except where the edit requires change; do not regenerate the whole asset to fix a text layer when a precise edit is available. [V3]

---

## 12. REPLICATING A REFERENCE IMAGE [HARD]

**Replicated, never altered:** camera height in meters, angle, tilt and distance; framing and how much of the body is in frame; composition and division of the frame; the character of the light. **Changed, mandatorily:** background and environment, scene objects, wardrobe, and identity where it applies — all from the product's market research. The reference is never replicated identically. The camera block is written once and pasted identically across the batch.

---

## 13. FILTERS, REJECTIONS AND RECOVERY

| Cause | Correction |
|---|---|
| Granular written physical spec of a minor | Supply the child via reference image; text carries only age, wardrobe, action, expression |
| `same face, same identity` with a photorealistic face reference | Describe by attributes plus the reference image |
| A driving video from another account with brands or a recognizable person | Not fixable in text: shoot original, license stock, or generate from scratch |
| Fire, injury or burns on a body part | Move the effect onto the adjacent object, keep it cartoonish, tell Mauro |
| Violence-adjacent slapstick | Frame as comedy, unhurt dazed ending |
| Minors in underwear, swimwear or partial dress | Ordinary full-coverage clothing |
| **Several jobs fail, all sharing one avatar image** [NEW 25-oct] | The avatar image is the cause: swap it, keep brands and dialogue, relaunch unchanged (7.3) |
| **Higgsfield returns a preset recommendation instead of a job** [NEW 25-oct, validated] | Resubmit the same request with `declined_preset_id` = the recommended preset's ID |
| A job fails with no reason | Do not silently change the concept. Isolate the shared element across failed jobs, rephrase only the likely trigger, keep every beat, tell Mauro |
| Job status unknown after a timeout | Reconcile the real status before resubmitting; a timeout is not a non-submission [V3] |

Report the actual error or moderation response. Do not infer a universal banned phrase from one rejection. For a quality failure identify the **smallest defective unit** with its timestamp or region, a cause hypothesis, the proposed correction and the elements to protect; never restage the whole story. [V3]

---

## 14. QA

### 14.1 Before submission — sixteen points

1. Does the first line declare 9:16 (creative) or the stated format (listing/packaging)?
2. Is every element of Mauro's brief present, in his order, with nothing invented or dropped?
3. Right mode (Lane A still, Lane B still, video showcase, video UGC, listing) with no vocabulary leaking?
4. Any banned word?
5. Identity lock or avatar reference placed right after the capture event, byte-identical?
6. Product reference attached and marked "copy exactly", parts counted, excluded items out, **scale anchor against the person who holds it**?
7. Video: one continuous take (or the cut Mauro asked for), 480p, exact duration, no music?
8. Video: camera exactly as briefed (POV / front / full body / medium distance / not shown)?
9. Video and showcase: bright, even, contact shadow under the product, no shadows across it, **no light equipment in frame**?
10. Hands clean, feminine, manicured, painted nails, gold bracelet wherever a woman's hands appear (campaign default)?
11. Showcase/unboxing/POV: action centered, product brought to the center of the lens?
12. Dialogue exact, short, natural American English, right speaker, right beat; silent beats silent?
13. Environment concrete, market-scoped markers, campaign-consistent, different across the batch where required?
14. Every important action with initial state → contact → consequence → final state; drops and handovers resolved?
15. Anti-blur block (stills) or the closing line "Phone footage, everything in focus, no blur, no bokeh" (video); physical product text preserved, no added captions?
16. Capability, bindings, cost and authorization resolved; nothing generated that was not asked?

### 14.2 After output [V3 method, HARD obligation]

- Measure duration, dimensions, audio track. Inspect every video: full playback with sound when the host allows it; otherwise frames at a declared sampling (the standard here is 2 fps contact sheets plus full-resolution crops of faces, labels and contacts) — then state that continuous motion and audio content are **unverified**, never "checked".
- Record a verdict per dimension: **pass / revise / unverified / not applicable** — brief fidelity, product truth and scale, physics and continuity, identity, emotion and clarity, image (light, focus, camera), audio and text, technical file.
- A defect is recorded as: time or region → observation → consequence → minimal correction → elements preserved. Separate observed defect, aesthetic preference and retention hypothesis.
- Report defects honestly, one line each. Never say it is right without checking. Retain good units; fix the smallest necessary part.

---

## 15. BLANK TEMPLATES

### 15.1 Still image (Lane A)

```
Vertical 9:16 portrait orientation, taller than wide.

[CAPTURE EVENT: who took the photo and why, one concrete sentence]

[IDENTITY LOCK: byte-identical, or "Reference image 1 is the woman — keep her face and hair exactly"]

[ACTION AND EXPRESSION: transitional state, unposed, with the emotion's trigger]

[PRODUCT LOCK: byte-identical, real dimensions and material, parts counted, scale anchor, mandatory wear]

[ENVIRONMENT: market-scoped markers, at least three clutter items]

[LIGHT: 5.1 for UGC/review shots; 5.0 for product-focused shots]

Photographed on a phone at [26 mm or 35 mm equivalent], everything in focus, deep
depth of field, no bokeh, slight lens distortion at the frame edges, fine ISO sensor
noise with luminance and chroma in the shadows, [one localized motion cue].

[FRAMING: off-center, excessive headroom for overlay]

Constraints: photorealistic, real photograph taken on a real camera, no added
captions or graphic overlays, preserve the physical text printed on the product,
no watermark, [object negations specific to this shot], no blur, no bokeh, no
shallow depth of field, no haze, no fog, no smoke, no atmospheric glow, no light
beam, no studio lighting
```

### 15.2 Video

```
Vertical 9:16 phone video, [N] seconds, one single continuous take, no cuts
[or: two scenes joined by one hard cut at [t] seconds, no other cuts][, tone: comedy /
ASMR / real family moment].

Reference image 1 is [the woman — keep her face and hair exactly].
Reference image 2 is [the boy, about 7 — keep his face and hair exactly].
Reference image 3 is [the retail box — copy its printed design exactly, including the logo].
Reference image 4 is [the product: parts counted — copy it exactly].

Camera: [POV from her eyes / locked wide shot, phone propped at about 1 m, slightly
wide, front three-quarter, faces and full bodies visible / medium distance, action
centered; who holds the phone and the one move with its origin and destination].

Setting: [signature environment or the location named, with market-scoped markers;
in a store, only the store's own ceiling fixtures].

Product scale: [real size + anchor against the person who holds it + where it sits
and where it never goes]. [LIGHT BEHAVIOR LOCK if it emits light, bounce quantified.]

Lighting is very bright, clean and even, as if two large soft light panels were
placed on the left and right sides just out of frame; [subjects] lit evenly from
both sides, a soft contact shadow under the product, no shadows across the product
or faces, every detail sharp and clear; the lights themselves are never visible.

[HANDS: clean, feminine, manicured hands with glossy painted nails and a gold
luxury bracelet on her wrist]

Beats in order, as one flowing action: [t–t: view, action with contact and release,
emotional trigger and response, new information, end state; dialogue lines in
quotes at their moment; reveal/pan instructions].

Audio: natural ambient sound, [named contact sounds] and the dialogue only; no music.

Phone footage, everything in focus, no blur, no bokeh.
```

Parameters: `aspect_ratio 9:16 · resolution 480p · duration [Mauro's seconds] · audio on · model seedance_2_5 · mode omni_reference · references by media_id or job_id`.

---

## 16. PRODUCT SHEET — ONE CANONICAL RECORD

One sheet per product line, stored in the host's persistent memory (in Claude: the product's area file; on disk: `mauro-data/products/<id>/product.md`). The full sheet is **not** pasted into every prompt: the PRODUCT LOCK, LIGHT BEHAVIOR LOCK, scale anchor and the environment chosen for the scene are read into the prompt verbatim. [V3: one record, no competing copies]

```
PRODUCT / ALIASES / ACTIVE VARIANT:
SOURCES AND DATE: [supplier sheet, product photos, competitor video, Mauro's statements]
APPROVED REFERENCES: [product image ID, packaging image ID, logo ID, 4K avatar IDs, rejected IDs per model]
PRODUCT LOCK (verbatim): [shape, colors, finish, every part counted, physical text]
REAL DIMENSIONS AND MATERIAL: [value + source]; NOT CONFIRMED: [list]
SCALE ANCHOR: [comparison object; anchor against a child/adult body; where it goes / never goes]
OPERATION: [preparation, operation, result, limits; what the box contains in each story type]
LIGHT BEHAVIOR LOCK: [only if it emits light: where it lands, color, falloff, bounce radius]
PACKAGING AND INCLUDED ITEMS: [layers, pieces]; EXCLUDED FROM SHOTS: [kit items]
MANDATORY WEAR (UGC stills only): [fingerprint, scuff, dust]
DEMONSTRATED BENEFITS / PENDING CLAIMS: [separated]
BUYER / USER / GIFT RECIPIENT: [from the market research, by purchasing power]
DESIRES, OBJECTIONS, ALTERNATIVES: [quotes from research, labeled observation/hypothesis]
ICP ENVIRONMENTS: [at least five, all different, from THAT product's market research]
TRIBE VOCABULARY: [slang for dialogue and copy]
TROJAN RETAIL: [specific store]
DISCARDED ANGLES / VALIDATED PATTERN: [history with reasons]
```

---

## 17. CAMPAIGN VARIABLES

Decided per campaign, stated once, held constant. Explicit current changes override; unrelated accepted choices persist. [V3]

```
MARKET / LANGUAGE: [default: United States, American English dialogue, 9.2 markers]
CASTING REGION: [appearance and demeanor]
RECURRING CHARACTERS / AVATARS: [identity locks + 4K reference IDs; rejected IDs per model]
SIGNATURE ENVIRONMENT: [default video background; weather in the window; season; lights on]
INTENTION AND EMOTION: [primary / secondary, from Content Factory §2]
HANDS & JEWELRY: [default ON: clean feminine manicured hands, glossy painted nails, gold luxury bracelet]
OVERLAY ZONE: [default: top]
BATCH SIZE: [videos: exactly the number requested · image prompts: Mauro's number, default 10]
VIDEO DEFAULTS: [9:16 · 480p · seedance_2_5 omni_reference · duration per video as stated]
IMAGE DEFAULTS: [9:16 · 2K · nano_banana_2 for UGC stills; gpt_image_2_5 for packaging/typography when asked]
PRESERVE / CHANGE / EXCLUDE: [map for each reference used in this campaign]
AUTHORIZATION SCOPE: [what is authorized: jobs, counts, retries]
```

---

## 18. HIGGSFIELD EXECUTION PROFILE — VERIFIED BINDINGS

These bindings were **verified on 25 October 2026** against the live tool contract. They are the current route, not assumptions; re-verify with `models_explore` if a call is rejected or the contract changes. [V3: discover, do not assume — but do not throw away a verified route]

- **Video:** `seedance_2_5`, `mode: omni_reference`, `resolution: "480p"` (explicit), `aspect_ratio: "9:16"`, `duration` whole seconds 4–30, `generate_audio: true`, references as `medias[] {role: image_references, value: media_id | job_id}`. Output measured 480×854. Several independent videos → `generate_video_batch`, one request per video, `count: 1`.
- **Preset interception:** if the submission returns a preset recommendation instead of a job, resubmit with `declined_preset_id` (validated: preset "IN THE DARK" 24bae836-2c4a-48e0-89b6-49fcc0b21612).
- **UGC stills:** `nano_banana_2` (Nano Banana Pro) with references, 9:16, 2K parameter. **Packaging / typography / listing:** `gpt_image_2_5` (variant `sunburst` or `flare`, `quality high`, `resolution 2k`, aspect as requested) with the logo and product as `image_references`.
- **Avatars:** upload (`media_upload` → PUT → `media_confirm`), then `upscale_image` (provider bytedance, `4k`); crop phone status bars and navigation buttons before upload; the 4K job ID is the reference.
- **Verification:** download the result; `ffprobe` for width, height, duration and audio stream; contact sheets at 2 fps; full-resolution crops of text, faces and contacts.
- **Cost discipline:** save every job ID; a timeout means unknown status (reconcile before resubmitting); failed jobs may still charge; never resubmit a whole batch because one unit failed; no retry without a diagnosis. [V3]

---

## 19. LEARNING LOG — FORMAT AND CURRENT ENTRIES [V3]

Store each pattern as: **name → observation and source (date, job IDs) → when it applies → when it does not → hypothesis → test → result.** Promote a criterion to a [HARD] rule only when it repeats across contexts; one render is not a law.

**Entries of 25 October 2026 (KickSprout):**

1. *Avatar image as the rejection cause.* Observation: 4 of 4 Seedance 2.5 jobs failed with avatar 02931e41 attached; the same prompts passed 4 of 4 after swapping only the avatar (a21f98b4). Brands in the prompts (PS5, Target, Starbucks, McDonald's) were not the cause. Status: rule (7.3).
2. *Preset interception.* Observation: batch returned "Preset IN THE DARK recommended" with zero jobs; `declined_preset_id` resubmission submitted 5 of 5. Status: rule (13, 18).
3. *Two-location video in one generation.* Observation: a 12 s request "two scenes joined by one hard cut at 6 s" rendered both scenes with the cut in place (job 1ffc2ad8). Status: validated route when Mauro asks for the cut (10.2).
4. *Light equipment leaking into a store scene.* Observation: a rectangular light panel appeared at the right edge of the Target reveal (job abf769f7) despite "never visible". Status: constraint added (5.0).
5. *Product shrinks in a child's hands.* Observation: the 80.5 cm trainer rendered toy-sized when lifted out of the box (job 1b6e15d6). Status: scale anchor against the holder's body is mandatory (8.2).
6. *Emitted-light bounce over-rendered.* Observation: "red light reading as a bounce on the rug" became a large red stain (job 1ffc2ad8, 10.5–12 s). Status: quantify radius and intensity (5.2).
7. *Unresolved release.* Observation: ice cream cone both on the floor and in the hand across 2.5–3.5 s (job 1ffc2ad8). Status: state the release and resting place (10.11).
8. *Packaging angle.* Observation: "front three-quarter" rendered almost frontal on GPT Image 2.5 (job d3705f33); text rendered correctly at 2K, logo copied exactly. Status: write the angle in degrees; hypothesis, to test.
9. *Door kick.* Observation: "the door bursts open, kicked from outside" rendered as a door simply opening (job 1b6e15d6). Hypothesis: describe the foot contact and the door's swing speed as observable action. To test.

---

*MAURO AI PROMPT SYSTEM V3.1 — 25 October 2026. Supersedes V2.2 and V3. Pair with Content Factory — Dropshipping Orgánico V3.1.*
