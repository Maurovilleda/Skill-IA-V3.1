# Memoria de proyecto y ejecución con Higgsfield (V3.1)

La skill contiene criterio y flujo. La conexión, el almacenamiento y la generación
dependen de herramientas reales del host. Un archivo `.skill` no añade credenciales,
créditos ni memoria permanente.

## 1. Dónde vive la memoria

**En Claude (Cowork / claude.ai):** la memoria persistente del usuario es el registro.
Un archivo de área por producto (`/areas/<producto>.md`) con la ficha, los IDs de
Higgsfield (producto, caja, logo, avatares 4K, imágenes rechazadas por modelo), las
variables de campaña, el patrón validado y las observaciones fechadas; los temas de
reglas (`/topics/prompt-frameworks.md`, `/topics/market-research.md`,
`/topics/higgsfield-workflow.md`, `/topics/genjutsu-workflow.md`). Se lee antes de
pedir nada; se actualiza al cerrar un encargo.

**En un entorno con archivos:** `mauro-workspace.json` en la raíz del proyecto
(plantilla en [templates](../templates/mauro-workspace.json)); `data_root` relativo a
esa raíz. Estructura:

```text
products/index.json
products/<product-id>/product.md
products/<product-id>/sources/
campaigns/<campaign-id>/campaign.md
projects/<project-id>/project.json
projects/<project-id>/brief.md
projects/<project-id>/requests/
projects/<project-id>/outputs/
projects/<project-id>/reviews/
```

No sobrescribir una configuración existente al iniciar una conversación. No simular
la escritura con un bloque de texto en el chat. Si no existe persistencia, declararlo
y entregar los archivos para que Mauro los conserve.

La ficha de producto sigue AI Prompt System §16 y Content Factory §12; la campaña,
AI Prompt System §17 y Content Factory §13. No mantener especificaciones
contradictorias en varios sitios.

**Al recuperar un producto:** buscar por nombre o alias; leer ficha y variante;
comprobar que las referencias siguen accesibles en Higgsfield (`show_medias`,
`show_generations`) y que su contenido concuerda; recuperar la campaña; reutilizar
decisiones válidas sin arrastrar marca, actores, props o guion de otro producto.

## 2. Estado del encargo

Registrar un proyecto solo cuando sirva conservarlo. Estados: `draft` (faltan
decisiones o inputs) · `prepared` (texto/plan listo) · `production_ready` (solicitud y
referencias resueltas, capacidad y costo verificados) · `running` (job enviado con ID)
· `generated` (resultado recuperado, sin revisar) · `reviewed_for_test` (archivo final
revisado) · `partial` (falta un componente o revisión) · `blocked` (dependencia
identificada).

## 3. Preparar una solicitud real

Confirmar que se pidió generación real. Usar los bindings verificados (sección 5) y
re-verificar con `models_explore` solo si una llamada falla por contrato (parámetro
rechazado, modelo no encontrado), no si falla por filtro.

Comprobar para este encargo: modelo exacto; proporción, resolución y duración
admitidas; cómo se vinculan las referencias (media_id de subida o job_id de
generación); audio; costo cuando Mauro lo pida (`get_cost`). Un archivo local y un
archivo remoto son cosas distintas: subir con `media_upload` → PUT → `media_confirm`
y conservar el mapeo.

Preferencias de Mauro, fijas: video Seedance 2.5 a 480p; imagen UGC Nano Banana Pro
a 2K; packaging y tipografía GPT Image 2.5 cuando lo pide; avatares a 4K; listing
1080 × 1080. No subir resolución, cambiar modelo ni incurrir en costo extra sin que
Mauro lo diga.

## 4. Referencias, unidades y prompt

Registrar cada asset con ID local, fuente real, tipo, variante, función de
referencia (identidad de producto, caja, persona, lugar, composición, movimiento,
luz, audio), estado de revisión y binding remoto. Una imagen de inspiración no cambia
el producto. Un avatar se usa siempre por su job de upscale 4K.

Preparar solo las dependencias que el plano necesita. Para un SKU concreto,
conservar sus referencias de identidad; no reemplazarlas por texto para ahorrar una
pregunta.

Compilar el prompt con AI Prompt System §15.2: referencias por índice con su rol →
cámara literal → setting con señas del mercado → escala y ancla → luz 5.0 → manos →
beats con contacto, emoción y estado final → audio → cierre anti-blur. Los metadatos
de investigación, costos y revisión se quedan fuera del prompt. Con referencias
adjuntas, el prompt va corto y directivo.

## 5. Bindings verificados de Higgsfield (25 de octubre de 2026)

| Uso | Herramienta y parámetros |
|---|---|
| Video, uno | `generate_video` · `model: seedance_2_5` · `mode: omni_reference` · `resolution: "480p"` · `aspect_ratio: "9:16"` · `duration: N` (entero, 4–30) · `generate_audio: true` · `medias: [{role: image_references, value: media_id o job_id}]` |
| Videos independientes | `generate_video_batch`, un request por video, `count: 1`; esperar con `jobs_wait`; mostrar con un solo `show_generation_by_ids` |
| Preset recomendado en vez de job | Reenviar el mismo request con `declined_preset_id: <id del preset>` |
| Imagen UGC | `generate_image` · `model: nano_banana_2` · 9:16 · 2K · referencias por media_id/job_id |
| Packaging / tipografía / listing | `generate_image` · `model: gpt_image_2_5` · `variant: sunburst` o `flare` · `quality: high` · `resolution: 2k` · aspecto pedido · logo y producto como `image_references` |
| Subir referencia | `media_upload` (filename, content_type) → `curl -X PUT` con el archivo → `media_confirm` (type image) |
| Avatar 4K | `upscale_image` · `image_id` · `width/height` reales · `resolution: 4k` → usar el job_id resultante |
| Buscar referencias guardadas | `show_medias` (subidas), `show_generations` (jobs, incluye upscales) |
| Verificar archivo | descargar `result_url`; `ffprobe` (ancho, alto, duración, pista de audio); cuadros a 2 fps |

Salida medida: video 480 × 854; imagen 2K cuadrada 2048 × 2048; upscale 4K ≈ 3089 × 4096 (depende del original).

## 6. Alcance, costos y jobs

Un video pedido = un job. Relanzar solo con diagnóstico (filtro, rechazo, defecto
identificado). Guardar cada job: `key, asset, revision, attempt, status,
provider_job_id, result_url, charged (si se conoce), evidence, updated_at`.

Estados de job: `reserved` · `submitting` · `pending` · `completed` · `unknown`
(timeout o sin respuesta: conciliar con `jobs_wait` o `job_display` antes de
reenviar) · `failed` (puede haber cargo) · `no_submission` (evidencia explícita de
que no se creó, por ejemplo un preset recomendado).

Una excepción o timeout no demuestra `no_submission`. Nunca repetir el lote completo
porque falló una unidad. Los intentos de reparación consumen créditos; tope práctico
cinco intentos en la misma toma, y después se cambia ángulo o referencia.

## 7. Acabado y recuperación

Guardar y revisar las salidas reales. Si Mauro pidió un video y hay varias unidades,
el conjunto sin ensamblar es parcial: decirlo. Reanudar leyendo el área del producto,
resolviendo jobs pendientes o inciertos y recuperando resultados antes de lanzar
nuevos. Una conversación nueva no reinicia el presupuesto ni invalida tomas
aceptadas.

Si falta acceso a Higgsfield, entregar el prompt completo y marcar la generación como
no ejecutada. No instalar otro proveedor ni publicar como fallback.
