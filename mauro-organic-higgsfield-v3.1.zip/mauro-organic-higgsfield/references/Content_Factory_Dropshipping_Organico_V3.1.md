# Content Factory — Dropshipping Orgánico V3.1

**Base de dirección creativa para video orgánico de producto — TikTok y Reels.**

Autor de la base: Mauro Villeda. Revisión V3.1: 25 de octubre de 2026. **Reemplaza a la V2 y a la V3 completas**; se conservan ambas como archivo.

**Cómo leer este documento.** Cada regla trae una etiqueta:

- **[DURA]** — regla validada en producción por Mauro (V2 + correcciones de septiembre y octubre de 2026). No es preferencia ni "adaptable": se aplica tal cual en todo video salvo que la orden actual de Mauro diga otra cosa para ese encargo.
- **[V3]** — método adoptado del paquete V3 porque suma algo que las reglas duras no cubrían (emoción como comportamiento, presupuesto de acciones, estados entre tomas, veredictos de revisión, aprendizaje con etiquetas).
- **[NUEVO]** — observación de la sesión KickSprout del 25 de octubre de 2026, con fecha.

**Compañero:** MAURO AI PROMPT SYSTEM V3.1 (inglés). Content Factory decide para quién es la pieza, qué transmite, cómo progresa y cuánto dura; AI Prompt System convierte eso en luz, cámara, física, continuidad, prompt, ejecución y revisión. Si chocan: AI Prompt System manda en luz, cámara, toma y encuadre; Content Factory manda en historia, emoción y tiempos.

**Qué corrige V3.1 respecto a V3.** V3 convirtió en opcionales la luz brillante sin equipo visible, la toma continua, el trojan retail, las señas de casa americana, el diálogo en inglés, el casting fijo por producto y la regla de manos. Esas reglas existen porque lo contrario ya falló en producción. V3.1 las conserva como [DURA] y toma de V3 solo lo que mejora la dirección y el control de créditos.

---

## 0. Prioridad de instrucciones [V3]

Dentro de las reglas del host: **la orden explícita actual de Mauro → los hechos confirmados del producto y sus referencias protegidas → las variables de campaña aprobadas (§13) → las reglas [DURA] de este documento y del AI Prompt System → los métodos [V3] → ejemplos, referencias y research.** Una petición creativa no vuelve cierta una función que el producto no tiene: se señala el conflicto y se ofrece una alternativa fiel.

## 1. La fórmula en una línea [DURA] y los tres resultados [V3]

Un video de dropshipping orgánico que convierte es una historia corta que un amigo te cuenta en video: filmada con celular, en un solo lugar real, con una persona creíble de la tribu del producto, donde el producto aparece hacia la cámara y termina demostrando lo que hace. No es un highlight. No es un anuncio.

**Qué no es este formato [DURA]:** no es "wow puro de producto" (se agota a los 20 videos); no es aspiracional imposible (patinadora profesional, chef estrella, atleta olímpico); no lleva música (el audio nativo cuenta la historia; la música, si acaso, en edición); no lleva precio, link ni marca dentro del video (todo va en overlay o comentarios); no se ve como anuncio (nada de luz de estudio, cámara flotante ni gente posando).

**Tres resultados distintos [V3]:** atención (se detiene y sigue mirando), interés útil (entiende el producto y busca más) y resultado comercial (visita, compra). Un video puede lograr uno sin los otros. Muchas vistas no son demanda; comentarios con palabra clave no son compras.

**Cinco preguntas antes de dirigir [V3]:** ¿a quién le importaría esta escena y por qué ahora? ¿qué quiere transmitir Mauro y qué de su guion es intocable? ¿qué emoción principal (y a lo sumo una secundaria) sirve a esa intención? ¿qué acción o detalle visible conecta esa emoción con el producto real? ¿qué debe entender o sentir la persona al terminar?

## 2. Emoción: elegirla y hacerla visible [V3, acotado por DURA]

La emoción no se añade escribiendo "muy emocionante". Necesita un estímulo visible y una respuesta que cambie con lo ocurrido.

| Intención | Cuándo sirve | Cómo se ve | Riesgo |
|---|---|---|---|
| Curiosidad | Hay algo relevante por descubrir | Información parcial, acción en curso, revelación que responde | Ocultar tanto que no se entienda qué se vende |
| Sorpresa / asombro | La forma, función o resultado es inesperado | Cambio visible y reacción posterior | Cara de asombro fija como máscara |
| Humor y juego | El producto permite una situación compartible | Preparación, acción cómica, remate ligado al producto | Espectáculo sin interés en el producto |
| Ternura / afecto | Cuidado, relación o regalo | Mirada, gesto, interacción y respuesta creíbles | Emoción genérica que serviría a cualquier objeto |
| Nostalgia | Asociación reconocible para ese público | Detalle o ritual que evoca | Fabricar recuerdos o testimonios |
| Identidad / pertenencia | El objeto significa algo para una tribu | Uso, lenguaje visual y contexto reconocibles | Decorar con símbolos sin entender al comprador |
| Alivio / comodidad | El uso responde a una fricción real | Situación inicial y cambio visible tras usarlo | Exagerar problema o eficacia |
| Satisfacción sensorial | Importan textura, encaje, manipulación | Acción completa y consecuencia perceptible; sonido pertinente | Movimiento repetitivo sin avance |
| Orgullo / deseo cercano | El producto expresa gusto o logro | Resultado alcanzable y fiel | Lujo genérico o resultado imposible |
| Frustración / tensión | El guion necesita una dificultad antes de resolverla | Obstáculo específico, consecuencia, resolución proporcionada | Fabricar miedo o humillar |

**Actuación [DURA + V3]:** estímulo → cambio de atención → gesto/postura → acción → recuperación o emoción final. El drama va solo en el hook; el resto son reacciones creíbles (sonrisa de lado, "oh", pulgar arriba, una risa). Una reacción grande evoluciona; no se sostiene como máscara mientras las manos hacen otra cosa, salvo que Mauro lo pida explícitamente para ese video ("sorprendida desde el primer cuadro"). La emoción del personaje y la del espectador pueden diferir: quien entrega un regalo anticipa; quien lo recibe descubre.

No forzar rostro ni diálogo si la emoción se comunica mejor con manos, producto o resultado. No inventar experiencias de clientes.

## 3. Apertura: por qué se detendría este comprador [V3, con reglas DURA]

El hook plantea el interés; "stop scroll" es la conducta que queremos observar, no una garantía. Tipos de apertura según guion y producto: reconocimiento de una situación · acción en curso con destino claro · descubrimiento (gesto o mirada lleva a algo y la cámara lo revela) · resultado primero · revelación parcial · interacción (regalo, reacción, momento social) · detalle significativo.

Registrar por separado: cuándo aparece el producto, cuándo se entiende qué es y cuándo se entiende qué hace. Ver una caja no equivale a entender su contenido; mostrar todo en el primer segundo tampoco es obligatorio.

**[DURA]** El hook estable del Formato A es una sola toma fija y abierta que cuenta la historia (regalo aventado, reacción, revelación, producto sacado hacia el lente). **El texto en pantalla se pone en edición, nunca se genera dentro del video**: hook arriba, tercio superior, blanco con contorno negro y 1–2 emojis, hablándole a la tribu ("[Tribu] lovers... this is for you", "DO NOT show this to a [miembro de la tribu]..."); al final cambia a CTA de comentario ("Comment [PALABRA] if you want one."). Si una referencia depende de un rótulo para dar sentido al gancho, esa función se traslada a la acción o al diálogo permitido; no se borra sin compensarla. [V3]

## 4. Estructuras: los dos formatos validados y el repertorio

### Formato A — Corto (7 a 10 s): hook + cortes de detalle [DURA]

| Parte | Tiempo | Qué pasa | Función |
|---|---|---|---|
| Hook estable | 3–5 s | Una sola toma fija y abierta | Detiene el scroll y cuenta la historia en una toma |
| Cortes de detalle | 0.5–2 s c/u | POV de manos abriendo/montando, close-up del producto | Muestra que es real y cómo se usa |
| Demo de función | 1–2 s | Botón → resultado (se prende, cambia, regresa la pelota) | El "ah, ya entendí" |
| Cierre en loop | 0.5–1 s | Termina en una posición que conecta con el primer cuadro | El video se repite sin que se note |

### Formato B — Arco (12 a 18 s): los 5 beats [DURA]

| Beat | Tiempo | Qué pasa | Función |
|---|---|---|---|
| 1 Descubrimiento | 2–3 s | Selfie o POV entrando a una tienda, momento previo al producto | Detiene el scroll, sitúa |
| 2 Unboxing lento | 4–6 s | POV al regazo, manos abriendo, componentes uno por uno | El motor que retiene |
| 3 Hero shot | 2–3 s | Plano cerrado del producto en la mano, girándolo al lente | Justifica el precio |
| 4 Activación | 2–3 s | Montaje o encendido: la primera vez que hace lo que promete | El wow |
| 5 Payoff ambiental | 4–6 s | Producto en su ambiente final, toma amplia y fija, sin apurar | La emoción de comprar |

**Regla no negociable [DURA]:** en el Formato B el payoff ocupa casi la mitad del video y no se apura. Si el clip termina en cuanto el producto se prende, no vendes: muestras.

**Relación con la toma continua [DURA]:** por default un video es UNA toma continua (AI Prompt System §10.2). Los "cortes" de ambos formatos se escriben como beats dentro de la misma toma (la cámara se acerca, baja al regazo, vuelve a abrir) salvo que Mauro pida cortes; entonces se usa una generación con el corte planeado (validado 25-oct con 12 s y dos locaciones) o unidades separadas unidas en edición.

### Repertorio para briefs abiertos [V3]

Cuando Mauro pide ideas sin guion, estas familias ayudan a organizar: demostración directa · problema y uso · descubrimiento · unboxing/colección · regalo o vínculo · humor o juego social · transformación/instalación · ritual/identidad/deseo · experiencia sensorial. Son repertorio; nunca sustituyen una historia que Mauro escribió. Un hero shot es un plano donde el producto se ve con claridad; no necesita giro publicitario.

## 5. Duración, ritmo y presupuesto de acciones

**[DURA]** Formato A de 7 a 10 s; Formato B de 12 a 18 s; la duración exacta la da Mauro por video y se respeta al segundo. Si no la da, se pregunta.

**[V3]** Beat = cambio de acción, información o emoción. Plano = toma continua. Corte = unión entre planos. Un movimiento de cámara cambia el encuadre sin corte; un plano puede contener varios beats. Presupuestar primero las acciones necesarias con su contacto, diálogo y resultado, y después repartir el tiempo. Ejemplos aritméticos, no plantillas: 9 s = 1.5 apertura + 4 acción + 2 revelación + 1.5 cierre; 12 s = 2 + 5 + 3 + 2; 15 s = 3 + 6 + 4 + 2. Si no cabe: identificar qué acción pide más tiempo y proponer quitar un paso secundario, ajustar duración o dividir con transición clara; si cambia una exigencia explícita, resolverlo con Mauro antes de generar. Los tiempos escritos son intención de dirección; se mide el render.

**Ritmo útil [V3]:** alternar preparación, acción y tiempo para leer el resultado. Un plano estable mantiene interés si algo progresa. No imponer un corte cada segundo.

## 6. Reglas duras técnicas [DURA]

### Higgsfield y créditos
- **Nunca generar nada que Mauro no pidió.** Sin pruebas, sin variaciones extra, sin re-runs sin orden. Un video pedido = una generación; se relanza solo si falló, con diagnóstico.
- **Modelo:** Seedance 2.5, modo omni_reference, con la foto real del producto, la caja y los avatares como referencias por media_id o job_id. **Resolución 480p** como parámetro explícito (ancho y alto solos salen en 720p). **Aspecto 9:16.** Audio nativo activado, sin música, sin voz en off.
- **Presets:** si Higgsfield recomienda un preset en vez de generar, se reenvía con `declined_preset_id` (validado 25-oct).
- **Antes de entregar:** verificar que el archivo sea 480p y 9:16, medir la duración, revisar cuadros y reportar defectos reales en una línea cada uno. Nunca decir que quedó bien si no quedó.

### Cámara
- Tomas abiertas fijas: celular en tripié o recargado, ultra gran angular (0.5x), a ~1 m de altura, cuerpo completo, leve distorsión en las orillas.
- Temblor de mano solo en POV de manos o caminando. Nunca "slight handheld shake" en todo el video.
- POV: del pecho al regazo en unboxing. Selfie cuando el descubrimiento es la gente. Cámara de amigo cuando hay varias personas.
- Máximo 3 tipos de toma por video: abierta fija · POV de manos · close-up del producto. Corte sobre la acción.
- Encuadre ligeramente gran angular de celular, imperfecto en UGC; centrado en showcase, unboxing y POV (AI Prompt System §10.4).
- Todo movimiento de cámara tiene origen, trayecto, destino y llegada legible; un señalamiento motiva el paneo. [V3]

### Luz
- **Siempre brillante, limpia y pareja.** Nunca escenas oscuras. Cara y fondo bien expuestos.
- Luz como si hubiera dos paneles suaves fuera de cuadro, a los lados; **el equipo de luz nunca se ve** (ni paneles ni stands, ni en casa ni en tienda). Las lámparas de la casa y las luminarias de la tienda pueden verse encendidas como objetos del cuarto. [NUEVO 25-oct: apareció un panel de luz en la esquina de una escena de Target; se añade la alternativa positiva "las únicas luces de la tienda son sus plafones".]
- Sombras (regla de octubre 2026): siempre sombra de contacto bajo el producto y micro-sombras de textura; ninguna sombra de mano, persona u objeto cruzando el producto o una cara.
- Mezcla de temperatura natural: piel cálida, blancos ligeramente fríos, color de celular sin gradear.
- En video NO aplican las sombras aplastadas ni el fallo de exposición del Lane A de imagen.
- Prohibido: cinematic, dramatic lighting, golden hour, studio lighting, look de anuncio.

### Continuidad
- Una sola locación por video (máximo dos si la historia lo exige y Mauro pidió el corte).
- Misma persona, misma ropa, mismo cuarto en todos los cortes.
- El equipo del producto solo se usa donde se usa en la vida real (patines solo en el hielo, tacos solo en la cancha; en tienda, casa y calle, tenis normales).
- **Estado por toma [V3]:** registrar producto (cerrado/abierto/armado/encendido), posición, orientación, qué mano sostiene qué, vestuario, props, hora y luz; la siguiente toma arranca de ese estado o establece el cambio.

## 7. Casting, ropa y entorno [DURA]

### Casting
- Relatable, no aspiracional: chica normal 25–35, pareja normal, mamá normal, abuelo normal. Nunca profesional imposible ni modelo.
- **Avatares principales por producto:** cada producto tiene su chica y su chico fijos, escalados a 4K en Higgsfield y usados como referencia de identidad en toda generación donde aparezcan. Son de ESE producto; no pasan a otro sin que Mauro lo diga. Si el modelo rechaza una imagen de avatar, se cambia la imagen (no se quitan marcas ni diálogo) y se anota el ID rechazado en la ficha. [NUEVO 25-oct]
- **Secundarios** (amigos, público, abuelo, empleados): mismo realismo que los avatares: foto de celular real, poros, pecas, brillo leve, ojeras, pelos sueltos, asimetría natural. Cada persona visible tiene una tarea y un foco de atención; no todos gesticulan a cámara. [V3]
- Nunca escribir "guapa/atractiva/hermosa": causa cara de plástico.
- **Menores:** por imagen de referencia; el texto lleva solo edad aproximada, ropa, acción, expresión, mirada y posición. Ropa ordinaria de cobertura completa.

### Ropa = identidad de la tribu
- Hiperespecífica al nicho y al mundo del producto (producto de frío → ropa de invierno; niño futbolero → calcetines en casa, jersey de equipo ficticio). Con uso real (arrugas, pelusa).
- Equipos y ligas ficticios. No agregar logos reales que Mauro no pidió; los que sí pidió se quedan (observación 25-oct: PS5, Target, Starbucks y McDonald's pasaron en Seedance 2.5).
- Manos de mujer: limpias, femeninas, uñas pintadas brillantes y pulsera dorada de lujo, en todo video e imagen donde aparezcan (default de campaña, Mauro puede apagarlo).

### Entorno
- Fondos y vibra salen del market research de ese producto; nunca un cuarto genérico. Los entornos rotan dentro de la tanda; el Signature Environment de la campaña es el ancla.
- Cuarto vivido con props de la tribu y, en UGC, mínimo 3 objetos de desorden real; en showcase, vivido pero ordenado.
- Temporada visible cuando justifica la compra (series, árbol, nieve en la ventana).
- **Señas reales del mercado** (variable MERCADO, default Estados Unidos): contactos de 120 V, apagadores de palanca plana, drywall con zoclo, ventanas de guillotina blancas; lista completa por tipo de cuarto en AI Prompt System §9.2. (V3 proponía no forzar casas americanas; se rechaza: el mercado es Estados Unidos y las señas van ligadas a la variable MERCADO, no se eliminan.)

## 8. Producto, actuación, diálogo y texto [DURA + V3]

### Producto en cada corte
- El producto se acerca al lente con la etiqueta de frente y legible. Interacciones táctiles: romper papel, aventar tela a la cámara, apretar botones, meter el objeto al lente.
- El close-up final es una demo de función: botón → resultado.
- **Tamaño y ubicación reales, siempre explícitos:** medidas, objeto de comparación, dónde va y dónde NUNCA va. Cuando una persona lo sostiene, el ancla se escribe contra su cuerpo ("tan ancho como los dos brazos del niño abiertos, a la altura de su rodilla"). [NUEVO 25-oct: sin ancla contra el cuerpo, el producto de 80 cm salió tamaño juguete en las manos del niño.]
- Productos que emiten luz: la luz se describe donde aterriza, nunca en el aire, con el LIGHT BEHAVIOR LOCK pegado tal cual y el rebote cuantificado ("un tenue reflejo rojo en el tapete a 10 cm del panel"). [NUEVO 25-oct]
- Lo que hay dentro de la caja lo decide el guion de ese video (producto armado o piezas sueltas), no un default.

### Física observable [V3]
Para cada acción importante: estado inicial → aproximación/contacto → fuerza o apoyo → consecuencia visible → estado final. Una entrega termina cuando el receptor carga el peso y el otro suelta; una apertura termina con el contenido accesible; una caída termina con el objeto en su lugar de reposo y la mano vacía ("el cono sale de su mano y cae al piso; su mano queda vacía"). Se escribe como acción visible en frases simples, nunca con el vocabulario prohibido del Lane B.

### Actuación
El drama va solo en el hook. El resto son reacciones creíbles. Sujeto a media acción, nunca posando. Arco de emoción de §2.

### Diálogo (corto, inglés americano real)

| Momento | Frases |
|---|---|
| Asombro de ella | "Shut UP! Babe!" · "Oh shit, babe, look!" · "Oh my God!" |
| Asombro de él | "Yo, WTF!" · "Holy shit!" · "No way!" |
| Señalamiento | "Babe, look!" · "Yo, LOOK!" · "Mom, look! Buy me that!" |
| Juego / jugada | "LET'S GO!" · "Oh SHIT!" · "That's sick!" · "One more round!" |
| Hype | "BOYS!" · "That's sauce!" |

Las frases que Mauro dicta se dicen exactas, en el momento y por quien él indica; si las escribe en español se traducen a inglés americano natural conservando el sentido. Nada de voiceover corporativo ni oraciones largas. Un beat sin línea en el guion queda sin línea. "Fuck" escrito completo es rechazo casi seguro; slurs nunca.

### Texto en pantalla
Se pone en edición, nunca generado dentro del video (§3). El texto físico del producto y la caja se conserva exacto; en el prompt se escribe "no added captions or graphic overlays; preserve the physical text printed on the product" en lugar de un "no text" que borraría la etiqueta. [V3]

## 9. Trojan retail — el gancho [DURA]

Es el truco de mayor retorno del sistema: filmar el descubrimiento del producto dentro de una tienda de confianza aunque el producto sea dropshipping. El cerebro del espectador rellena la historia ("lo compraron ahí") y genera comentarios de "where did you get it?".

**Cómo se usa:** se abre con selfie o POV afuera de la tienda con su logo visible, o adentro pasando entre estantes y racks; después se corta al uso o al unboxing. Nunca se dice "lo compramos en X": se deja implícito. Los personajes entran a la tienda con ropa y calzado normales.

| Nicho | Tiendas trojan válidas |
|---|---|
| Moda / accesorios / lifestyle | Zara, Urban Outfitters, Anthropologie, H&M |
| Deporte / hockey / fitness / fútbol infantil | Dick's Sporting Goods, Walmart, Play It Again Sports, Scheels, REI, Target, Costco |
| Hogar / decoración / regalo | IKEA, Target, HomeGoods, West Elm |
| Tecnología / gadgets | Best Buy, Target, Apple Store (arriesgado) |
| Mascotas | PetSmart, Petco, Chewy pop-up |
| Bebés / niños | Buy Buy Baby, Target, Pottery Barn Kids |
| Regalo genérico Q4 | Target, Walmart, Costco, IKEA, vitrina de centro comercial |

**Regla legal [DURA]:** solo se muestra la fachada, el pasillo o el rack de la tienda real; nunca se le atribuye la venta del producto en el copy; nunca se imprime texto ni logos falsos dentro del video. El trojan es visual, no textual. (V3 desaconsejaba el trojan por completo; Mauro decide mantenerlo con esta regla. Observación 25-oct: las escenas de Target con logo pasaron en Seedance 2.5.)

## 10. Fórmulas por tipo de producto [DURA]

La estructura (§4) es el envase; el ángulo es el contenido.

| Fórmula | Cuándo aplica | Apertura | Cierre / payoff |
|---|---|---|---|
| Humor + regalo | Producto prank o de broma (ScrewBox, Throne Golf) | Cara del que da el regalo, sonrisa cómplice | Reacción del que lo recibe |
| Nostalgia + regalo | Producto de recuerdo (MemoryMold) | El que compra, mirando el producto con emoción | Reacción del abuelo, mamá, familiar |
| POV + utilidad | Resuelve un problema diario (Dreamora, CleanPaws) | El momento del problema | Producto resolviendo, ambiente calmado |
| Identidad de nicho + wow | Nicho con identidad fuerte (SpellDice, PetGorgon) | Descubrimiento en tienda o ambiente del nicho | Producto en uso dentro del ritual del nicho |
| Problema + POV | Resuelve un problema visible (CozyVolt, KickSprout) | El problema desde POV (el niño rebotando contra las paredes) | Producto en uso, ambiente cómodo, la pelota regresando |
| Wow social + trojan | Producto LED, RGB, cambio de color (FrostBeam, PolarShift) | Pareja o amigos en tienda trojan, o reacción en gradas | El grupo usando el producto en su ambiente |

## 11. Los 13 patrones que hacen que funcione

**[DURA]** 1. Dos formatos: corto 7–10 s o arco 12–18 s; nunca un clip suelto sin historia. 2. Un hook estable que cuenta la historia en una toma. 3. El producto hacia el lente en cada corte, con etiqueta legible. 4. Cierre con demo de función; en el Formato B el payoff respira casi la mitad. 5. Una sola locación, misma persona, misma ropa. 6. Cámara fija en tomas abiertas; en mano solo en POV. 7. Casting relatable con ropa de la tribu y del mundo del producto. 8. Luz brillante y pareja, sin equipo visible; nunca oscuro, nunca look de anuncio. 9. Reacciones creíbles + diálogo corto real; drama solo en el hook. 10. Sin precio, link ni marca dentro del video; hook y CTA en overlay.

**[V3]** 11. La emoción tiene estímulo visible y evoluciona; no es una máscara. 12. Los contactos importantes se ven: entrega con peso transferido, apertura con contenido accesible, caída con lugar de reposo. 13. Cada toma arranca del estado en que terminó la anterior.

## 12. Ficha universal de producto — un solo registro

Se llena una vez por producto y es la fuente canónica para ambos documentos (campos en AI Prompt System §16). Se guarda en la memoria persistente del host (en Claude, el archivo de área del producto; en disco, `mauro-data/products/<id>/product.md`). No se pega completa en los prompts: se leen el PRODUCT LOCK, el LIGHT BEHAVIOR LOCK, el ancla de escala y el entorno de la escena. Lo desconocido queda marcado como pendiente; nunca se inventa. [V3]

Campos que vienen de este documento: avatares (chica y chico en 4K), ropa y temporada, reglas de uso real, fórmula primaria (§10), trojan retail, casting secundario, vocabulario de la tribu, entornos ICP (mínimo 5 del market research), ángulos descartados y patrón validado.

## 13. Variables de campaña y brief corto

Se guardan separadas de la ficha para no confundir decisiones creativas con propiedades del producto (lista completa en AI Prompt System §17): mercado e idioma (default Estados Unidos, inglés americano), público prioritario, intención y emoción principal/secundaria, avatares y referencias, vestuario y manos, Signature Environment y cambios permitidos, sonido/diálogo, duración y cantidad, defaults técnicos, mapa preservar/cambiar/excluir de cada referencia, alcance autorizado.

**Brief de una línea [DURA]:** producto + ángulo + trojan retail o locación + avatar + duración. Ejemplos: "FrostBeam. Ella en las gradas reacciona al juego rojo vs azul. Pista. Avatar chica. 7s." · "KickSprout. Mamá en selfie en Target descubre el rack. 6s." Si la orden cambia una sola variable, se recuperan las demás de la ficha y la campaña; no se le pide a Mauro reenviar lo que ya está guardado. [V3]

## 14. Flujo operativo

### Producto NUEVO [DURA]
1. **Market research completo primero**, con el prompt fijo de Mauro (Universal Deep Market Research Prompt): Reddit con 15–20 citas, reseñas de 1 y 3 estrellas, foros, comentarios de TikTok, Ads Library, cuentas orgánicas, Trends; las 11 secciones; audiencias ordenadas por poder adquisitivo; hashtags por segmento. Se entrega en .docx en español. Nada inventado, todo con fuente.
2. Se llena la ficha (§12) con hechos y pendientes; se suben producto, caja y logo a Higgsfield; se suben y escalan a 4K los avatares.
3. Mauro escribe la historia o guion en prosa: vibe, emoción, momentos.
4. Claude lo estructura en Formato A o B, aplica las reglas técnicas y arma el prompt completo de Seedance.
5. Se genera solo lo pedido. Claude revisa cuadros, mide el archivo y reporta defectos. Mauro corrige.
6. Cuando pega, se guarda como patrón validado del producto.

### Producto YA MAPEADO [DURA]
Mauro manda el brief de una línea con las variables que cambian; Claude aplica el patrón guardado y solo mueve esas variables; se genera; iteración rápida.

### Recorridos según la orden [V3]
- **Guion entregado:** extraer objetos, acciones, orden, frases, duración, perspectiva y exclusiones; completar decisiones de dirección sin cambiar la historia; no exigir research nuevo ni presentar cinco conceptos para ejecutar un guion.
- **Ideas sin guion:** usar la ficha y la evidencia para elegir situación, emoción y función visible; entregar la cantidad pedida; etiquetar hipótesis.
- **Corrección o comparación:** recuperar el resultado exacto y su versión; distinguir cambio de gusto, defecto visible y problema de rendimiento con datos; cambiar la unidad mínima y conservar lo aceptado; no reiniciar el research ni toda la producción por un cambio local.

## 15. Tabla interna de dirección [V3]

Se usa cuando ayuda a controlar la escena; no es un formulario para Mauro ni va en el prompt.

| Campo por unidad | Decisión |
|---|---|
| Intervalo | Inicio y fin previstos; suma compatible con la duración |
| Función | Qué aporta al comprador o a la historia |
| Primer estado | Qué se ve y dónde está cada elemento |
| Cámara | Plano, perspectiva y movimiento con destino |
| Acción | Contacto, apoyo y cambio necesarios |
| Emoción | Estímulo, respuesta observable y evolución |
| Producto | Identidad y función protegidas, ancla de escala |
| Luz y fondo | Cómo se hace legible la acción |
| Estado final | Qué cambió y qué conserva la siguiente toma |
| Sonido / texto | Solo lo permitido y exacto |
| Aceptación | Qué tendría que verse para dar la unidad por cumplida |

## 16. QA antes de generar y antes de entregar

### Antes de mandar el prompt [DURA]
¿Mauro pidió exactamente este video (nada extra)? ¿Formato A o B con sus tiempos y la duración exacta? ¿Una sola locación y cámara fija en tomas abiertas? ¿Casting relatable, avatares del producto en 4K, secundarios con el mismo realismo, ropa del mundo del producto? ¿Producto con tamaño real, objeto de comparación, ancla contra el cuerpo y ubicación exacta? ¿Referencias por media_id/job_id en omni_reference, etiquetadas por índice? ¿480p explícito y 9:16? ¿Audio nativo con diálogo corto real, sin música? ¿Sin logos reales no pedidos, sin texto generado, sin precio? ¿Luz brillante sin equipo visible, sombra de contacto, nada cruzando el producto? ¿Constraints con las reglas del producto (light behavior, no beam, no glow en el aire)? ¿En Formato B el payoff respira? ¿Cada acción con estado inicial, contacto, consecuencia y estado final? [V3]

### Antes de entregar [DURA + V3]
Medir que el archivo sea 480p, 9:16 y la duración exacta. Revisar cuadros (la cobertura estándar aquí: hoja de contactos a 2 fps más recortes a resolución completa de caras, textos y contactos) y declarar que movimiento continuo y audio quedan **sin verificar** si no se reprodujeron. Registrar veredicto por dimensión — **aceptable / corregir / no verificable / no aplica** — en: fidelidad al guion, producto y escala, física y continuidad, identidad, emoción y claridad, imagen, audio y texto, archivo técnico. Reportar los defectos con honestidad, una línea por defecto, con tiempo o región → observación → consecuencia → corrección mínima → qué se conserva.

## 17. Errores documentados

*Cada uno ya pasó. No repetir.*

**Estructura [DURA]:** generar un clip suelto sin historia como "el video" · empezar por el payoff esperando que arme historia solo · apurar el cierre en 1 s en el Formato B · meter 3 locaciones en 7 s (la IA rompe continuidad).

**Casting y ropa [DURA]:** profesional imposible · "guapa/atractiva/hermosa" en el prompt · equipo fuera de su lugar real (patines en Walmart) · ropa fuera de contexto · logos de equipos reales que nadie pidió.

**Luz, cámara y estilo [DURA]:** luz baja y oscura · "slight handheld shake" en todo el video · cinematic, dramatic lighting, golden hour · música en la generación.

**Producto [DURA]:** no adjuntar la foto real del producto (el modelo lo inventa) · no decir tamaño y ubicación exactos (sale gigante o diminuto y donde no va) · prompt larguísimo con referencia adjunta (con referencia, corto y directivo) · no incluir el comportamiento físico del producto.

**Créditos y proyecto [DURA]:** mandar solo ancho y alto (sale 720p y cuesta más) · generar cosas no pedidas · trabajar varios productos en el mismo chat · no guardar el patrón validado.

**Nuevos, 25 de octubre de 2026 [NUEVO]:**
- Relanzar una tanda rechazada sin aislar el elemento compartido: en KickSprout la causa fue una imagen de avatar, no las marcas (7.3 del AI Prompt System).
- Aceptar la recomendación de preset de Higgsfield como si fuera el job: se reenvía con `declined_preset_id`.
- Dejar sin cuantificar el rebote de un producto que emite luz: salió una mancha roja en el tapete.
- No anclar la escala contra el cuerpo de quien sostiene el producto: salió tamaño juguete.
- No cerrar la física de una caída: el helado quedó en el piso y en la mano a la vez.
- Confiar en "lights never visible" sin la alternativa positiva en una tienda: apareció un panel de luz.
- Subir un avatar desde captura de pantalla sin recortar la barra de estado y los botones del teléfono.

## 18. Investigación, ejemplos y aprendizaje [V3, con el método DURA de Mauro]

Para un **producto nuevo**, el research es el completo de §14 (prompt fijo de Mauro). Para una **decisión concreta** posterior (un ángulo, una objeción, una apertura), se investiga solo lo que cambia esa decisión, con fuente y alcance; no se repite el estudio completo por una corrección.

Etiquetar toda información: **hecho documentado** (fuente y alcance) · **observación** (lo visto, medido o escuchado, con fecha y cobertura) · **preferencia** (decisión de Mauro) · **hipótesis** (expectativa a probar) · **pendiente** (no verificado). Una paráfrasis no se escribe como cita; no se fabrican reseñas, cifras ni comentarios.

Las referencias de competidores se analizan por mecanismo (qué información cambia, qué crea curiosidad, qué hace entender el beneficio, qué invita a compartir), no solo por estética. Separar defecto observado, preferencia creativa, hipótesis y resultado medido. "Bueno" y "malo" dichos por Mauro son etiquetas creativas hasta tener datos.

Guardar cada patrón como: nombre → observación y fuente → cuándo sirve → cuándo no → hipótesis → prueba → resultado. No convertir una observación de cinco videos en fórmula para todos los productos; no reescribir toda la base por un render fallido.

## 19. Métricas que sí permiten aprender [V3]

Primero calidad y comprensión: comparar la versión actual con una corrección concreta manteniendo guion, producto, referencias, modelo y duración; registrar todas las salidas, no solo la mejor. Después respuesta real: definir variable cambiada, objetivo, ventana y denominadores antes de comparar.

| Señal | Qué puede ayudar a estudiar | Qué no demuestra sola |
|---|---|---|
| Retención inicial / curva | Apertura y pérdidas en momentos específicos | Causa única de abandono |
| Tiempo medio y finalización | Consumo relativo a duración | Interés de compra |
| Repeticiones, compartidos, guardados | Relevancia o utilidad | Satisfacción |
| Comentarios de uso/precio, visitas al perfil | Curiosidad comercial | Demanda sostenida y ventas |
| Clics, pedidos, ingresos atribuibles | Respuesta comercial bajo esa atribución | Causalidad exclusiva del creativo |

Un patrón puede quedar **aceptado visualmente**, **prometedor en atención** o **respaldado comercialmente en un contexto**; no son equivalentes. Si hay atención sin clics: revisar pertinencia, comprensión y siguiente paso. Si hay clics sin compra: oferta, tienda, envío y expectativas, no solo el creativo.

## 20. Plantillas de prompt Seedance

Los corchetes son referencia; en el prompt final se expanden con contenido real y nunca se dejan como placeholder. La plantilla completa de video, con referencias por índice, ancla de escala, luz 5.0, manos, beats con contacto y estado final, está en AI Prompt System §15.2; se usa esa.

**Formato A — Corto (7–10 s):** `Vertical 9:16 phone video, [N] seconds, one single continuous take, no cuts` → referencias por índice → cámara (hook fijo, 0.5x, ~1 m, una locación) → setting con señas del mercado → escala real + ancla → luz 5.0 → manos → beats: hook 0–[X]s con el producto hacia el lente y etiqueta legible; detalle POV [X]–[Y]s; demo de función [Y]–[N]s terminando en cuadro que hace loop → audio ambiente + diálogo, sin música → `Phone footage, everything in focus, no blur, no bokeh.`

**Formato B — Arco (12–18 s):** mismos bloques con los cinco beats en su orden (descubrimiento con trojan si aplica y tenis normales en tienda; unboxing POV al regazo; hero shot girando al lente; activación; payoff ambiental en toma amplia fija sin apurar).

Parámetros fuera del prompt: `model seedance_2_5 · mode omni_reference · aspect_ratio 9:16 · resolution 480p · duration [N] · generate_audio true · medias image_references por media_id/job_id · declined_preset_id si aplica`.

## 21. Mantenimiento

Guardar este documento y el AI Prompt System V3.1 como referencia operativa. Cada producto nuevo: ficha + avatares + market research antes de cualquier prompt. Actualizar por versiones con registro (regla conservada, mejora, motivo, evidencia, resultado) cuando haya un patrón validado nuevo; conservar originales. Son reglas operativas, no filosofía: si algo no sirve en la práctica se cambia; si algo se rompe, se documenta como error con fecha.

*Content Factory — Dropshipping Orgánico V3.1 · 25 de octubre de 2026 · reemplaza V2 y V3.*
