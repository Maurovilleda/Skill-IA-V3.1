# Investigación, copy e infografías (V3.1)

Complementa las dos bases V3.1. Dos niveles de research, con reglas distintas: el
**market research completo** de un producto nuevo (método fijo de Mauro, obligatorio
antes de cualquier contenido) y la **investigación puntual** de una decisión concreta
(método V3, proporcional al encargo).

## 0. Market research completo de producto nuevo [DURA]

Es lo primero que se corre con cada producto nuevo, con el **Universal Deep Market
Research Prompt** de Mauro: 2–3 fotos del producto + descripción, público y
categoría. Se entrega completo, en español latino, como .docx (abre en Pages).

**Fuentes en orden de prioridad, nada inventado, todo con fuente:** Reddit (la de más
peso: 15–20 citas textuales con subreddit) · reseñas de Amazon de 3 y 1 estrella de
competidores (10 citas; si Amazon bloquea, Walmart, Wayfair, Sam's Club, Trustpilot
y marketplaces equivalentes del mismo producto) · foros y grupos del nicho ·
COMENTARIOS de TikTok (no los videos; si están bloqueados, las reseñas del mismo
producto son el proxy y se dice) · Facebook Ads Library · cuentas orgánicas y
dropshippers en TikTok e Instagram · Google Trends y People Also Ask.

**Las 11 secciones:** ICP como avatar exacto (nombre, edad, trabajo, ingreso, rutina,
qué scrollea, qué compró y por qué falló, qué desea, qué lo hace sacar la tarjeta,
sus palabras exactas) · top 3 dolores · top 3 beneficios con el momento "ajá" · cómo
funciona el producto (listo para voiceover) · mínimo 5 entornos de video con luz,
props y por qué funcionan · disparadores de identificación (8–10) y 10 hooks de
texto etiquetados · 8 hooks visuales + 3 hooks WTF con nivel de riesgo · top 5
ángulos etiquetados viral/conversión con guion de 4–6 líneas · inteligencia de
competencia paga y orgánica con whitespace · cheat sheet · banco de lenguaje (20+
frases reales con fuente, agrupadas por emoción).

**Reglas propias de Mauro:** empezar por la intención original de fábrica del producto
y cómo lo posiciona el proveedor; listar primero las audiencias con MÁS poder
adquisitivo (vende en Estados Unidos); ángulos con sentido real (esa audiencia ya
compra productos similares); hashtags separados por segmento siempre, aunque no los
pida; specs no confirmadas marcadas como tales y pedidas al proveedor; las citas se
dejan en inglés (es el lenguaje de los overlays) con glosa en español donde ayude.

El banco de lenguaje y los disparadores son el cimiento: todo lo demás se construye
sobre ellos. La longevidad de un anuncio en Ads Library se lee como prueba de que
convierte.

## 1. Investigar una decisión concreta [V3]

Para un ángulo, una objeción, una apertura o un entorno nuevo de un producto ya
mapeado: definir qué decisión se quiere resolver, recuperar primero la ficha y el
research guardado, comprobar vigencia y buscar solo lo que cambia esa decisión. No
repetir el estudio completo por una corrección de un video.

Registrar por hallazgo: fuente y alcance (URL, fecha, mercado, parte accesible) ·
observación (qué muestra realmente) · situación (qué desencadena interés, quién usa,
paga o regala) · deseo y alternativa · objeción · implicación creativa · límite
(contradicciones, falta de datos).

Distinguir observado, declarado por Mauro, afirmado por el vendedor, inferido y
propuesto. Una paráfrasis no se escribe como cita. No fabricar entrevistas, reseñas,
cifras ni comentarios. Un bloqueo de una plataforma no permite afirmar que se revisó
el contenido: se busca el proxy accesible y se señala el límite.

## 2. Analizar referencias de competidores

Primero el **efecto del producto**, no el gancho: qué hace físicamente, cómo lo usa
la persona (distancia, pies, manos, ritmo), en qué superficie, qué se ve del
producto en uso, qué dice el entorno. Después el hook y la estructura: primer
cuadro, cuándo aparece el objeto, cuándo se entiende, función demostrada, cortes,
luz, actuación, sonido, texto. Anotar tiempos medidos y cobertura (cuadros
extraídos a qué fps), no rellenar huecos.

Separar: defecto observado · preferencia creativa · hipótesis · resultado medido.
"Bueno" y "malo" dichos por Mauro son etiquetas creativas hasta tener datos. Extraer
reglas condicionales ("para esta acción, mostrar el apoyo permite entender el peso"),
no leyes universales.

Si el competidor es una marca distinta del mismo producto, corregir la ficha y el
research con lo que se vio (por ejemplo, 25-oct: el "Infinity Kicker" resultó ser el
360 Kicker en pallets de Costco; el research se actualizó).

## 3. Elegir mensaje y emoción

Conectar evidencia → situación del ICP → deseo/objeción → función real del producto
→ intención emocional (Content Factory §2) → acción visible → respuesta que se desea
comprobar. Comprador, usuario y destinatario pueden diferir (mamá compra, niño usa,
abuela regala). No asignar motivaciones por género, país o edad sin contexto.

Si Mauro entrega un guion, estas preguntas ayudan a dirigirlo; no autorizan
reemplazar su historia.

## 4. Copy, ganchos, guiones y captions

Entregar exactamente el tipo y cantidad pedidos. Los ganchos de texto van en inglés
americano, menos de 10 palabras, como monólogo interno de la audiencia, etiquetados
por disparador (situación, frustración, pensamiento secreto, intento fallido,
afirmación atrevida, identidad, curiosidad). El diálogo de video sigue Content
Factory §8. Un prompt técnico en inglés no traduce por sí mismo el diálogo: la línea
se escribe tal cual se dirá.

Preferir detalles concretos a elogios intercambiables. No inventar escasez,
descuentos, resultados, reseñas ni disponibilidad en tiendas. Antes de cerrar:
¿la apertura corresponde a lo que muestra el video? ¿se entiende en ese tiempo?
¿las frases suenan naturales dichas en voz alta? ¿hay hechos que necesiten fuente?
¿el CTA, si existe, apunta a una acción real? El CTA de comentario va en overlay al
final, no dentro del video.

## 5. Infografías, listing, packaging y variantes

Se generan cuando se piden, no como complemento automático de cada video. Listing e
infografías: 1080 × 1080, paleta de marca, un mensaje dominante, headline corto y
máximo tres etiquetas, nada cortado ni mal escrito; cada infografía de un set
claramente distinta. Packaging: el formato que Mauro indique (25-oct: 1:1 a 2K en
GPT Image 2.5 Sunburst), con su logo y el producto como referencias "copy it
exactly", una sola caja, ángulo escrito en grados y panel lateral nombrado.

Mantener un manifiesto de texto exacto (título, etiquetas, unidades, orden). Las
medidas y componentes necesitan fuente. Conservar identidad y colores del producto;
adaptar cada proporción con composición, nunca deformando el original. Tipografía
legible a tamaño de teléfono.

Revisar el exportado completo a resolución real: palabras y números exactos,
recortes, color, producto, orden, legibilidad. Para corregir una letra sobre una
imagen aprobada, edición puntual; no regenerar todo.

## 6. Entregar investigación utilizable

Para research solicitado: comprador y situación, hallazgos con fuentes,
contradicciones, implicaciones creativas, qué falta comprobar y qué no se pudo
acceder (con el proxy usado). Para una generación, mantener el análisis interno y
comunicar solo la decisión útil o una incertidumbre material.

Guardar el conocimiento por alcance: hechos del producto en su ficha, decisiones de
campaña en su registro, aprendizajes con su evidencia y fecha. No convertir fuentes
ni research completo en texto que se manda al generador.
