# Revisión y aprendizaje (V3.1)

Leer las reglas de revisión de AI Prompt System §14 y Content Factory §16–19. Este
documento organiza evidencia y decisiones; no sustituye mirar el archivo.

## 1. Antes de generar

Correr los 16 puntos de AI Prompt System §14.1 y la lista de Content Factory §16.
Un guion con demasiadas acciones para su duración se resuelve antes de gastar,
conservando sus requisitos y preguntando a Mauro si hay que quitar un paso. No
exigir que cada escena tenga personas, reacción, CTA o texto: un video sin personas
puede vender con uso, detalle o resultado.

## 2. Revisar el resultado real

Identificar archivo, job y versión exactos. Medir con `ffprobe`: ancho, alto,
duración, pista de audio. La cobertura estándar en este host: descargar el archivo,
hoja de contactos a 2 fps, recortes a resolución completa de caras, textos, producto
y contactos (manos sobre objeto, entrega, caída). Si el host permite reproducir el
video con audio, hacerlo y decirlo. Si solo se vieron cuadros, declarar el muestreo y
dejar **movimiento continuo y audio como no verificados**; una pista de audio
presente no demuestra que diga lo correcto.

Veredicto por dimensión — `pass` · `revise` · `unverified` · `not_applicable` — con
evidencia y tiempo o región:

| Dimensión | Pregunta verificable |
|---|---|
| Fidelidad | ¿Historia, orden, frases, duración y exclusiones del brief? |
| Producto y escala | ¿Variante, partes, colores, texto físico y tamaño contra quien lo sostiene? |
| Física | ¿Contacto, apoyo, peso, liberación y respuesta de material coherentes? |
| Continuidad | ¿Estados, piezas y posiciones enlazan sin cambios inexplicados? |
| Identidad | ¿Cara y pelo iguales a la referencia 4K en todos los cuadros? |
| Emoción y claridad | ¿Estímulo, respuesta y evolución; se entiende qué es y qué hace? |
| Imagen | ¿Luz 5.0, sin equipo visible, foco, cámara, color, detalle? |
| Audio y texto | ¿Diálogo exacto, sin música, texto físico intacto, sin rótulos generados? |
| Archivo | ¿480p, 9:16, duración exacta, pista de audio, reproduce? |

`not_applicable` significa que el criterio no existe en el encargo, no que no se
pudo inspeccionar. Usar la plantilla de [revisión](../templates/review.md).

Una revisión propia en una pasada separada se describe como tal. Revisar el
exportado después del montaje; revisar otra vez la parte cambiada tras una
corrección.

## 3. Diagnosticar sin inventar causas

Describir el hecho antes de la hipótesis: "entre 2.5 y 3.5 s el cono está en el piso
y en la mano a la vez" permite corregir mejor que "se nota IA". No atribuir una
forma rara a un modelo o a una frase sin evidencia comparativa; no inferir una
palabra prohibida universal de un solo rechazo. Si varios jobs fallan, aislar el
elemento que comparten antes de cambiar nada (25-oct: fue la imagen de avatar, no
las marcas).

Distinguir nitidez, estética, actuación y credibilidad. Elegir la reparación menor:
una frase del prompt (ancla de escala, rebote cuantificado, liberación de un objeto),
una referencia aguas arriba (avatar), o la estructura completa si el problema es
global. Conservar lo aceptado. No prometer que un cambio de prompt garantiza el
render; los reintentos se rigen por el alcance de memoria y ejecución §6.

## 4. Aprender con métricas

Separar calidad revisada, atención, interés comercial y venta. Por publicación
conservar fecha, plataforma, producto/variante, formato, duración, mercado,
exposición, ventana de medición y si hubo distribución pagada (Mauro no corre ads;
si un video se impulsa, anotarlo). Usar las definiciones reales del canal.

| Señal | Qué puede ayudar a estudiar | Qué no demuestra sola |
|---|---|---|
| Retención inicial o curva | Apertura y pérdidas en momentos específicos | Causa única de abandono |
| Tiempo medio y finalización | Consumo relativo a duración | Interés de compra |
| Repeticiones, compartidos, guardados | Relevancia o utilidad | Satisfacción |
| Comentarios de uso/precio y visitas | Curiosidad comercial | Demanda sostenida |
| Clics, pedidos, ingresos atribuibles | Respuesta comercial bajo esa atribución | Causalidad exclusiva del creativo |

Para comparar, conservar producto, duración, público y contexto lo más parecidos y
cambiar una variable principal; dos publicaciones ordinarias son comparación
observacional, no A/B. Registrar contraejemplos.

## 5. Actualizar reglas sin sobreajuste

Registrar hipótesis, cambio, resultado, contexto y decisión con fecha y job IDs
(bitácora en AI Prompt System §19). Promover un criterio a regla [DURA] solo cuando
se repite en contextos distintos. No cambiar las bases por una sola publicación ni
por un render fallido; proponer la mejora con su evidencia y conservar la versión
anterior cuando se adopte.
