# Revisión del resultado (V3.1)

- Producto, video/imagen, job ID y versión exacta:
- Tipo de revisión (propia, pasada separada):
- Cobertura visual (reproducción completa / cuadros a N fps / recortes a resolución completa):
- Cobertura de audio (reproducido / no verificado):
- Mediciones (ancho × alto, duración, pista de audio):

| Dimensión | Veredicto | Evidencia, tiempo/región y límite |
|---|---|---|
| Fidelidad al guion | unverified | |
| Producto y escala | unverified | |
| Física y materiales | unverified | |
| Continuidad | unverified | |
| Identidad (avatar 4K) | unverified | |
| Emoción y claridad | unverified | |
| Imagen (luz 5.0, sin equipo visible) | unverified | |
| Audio y texto | unverified | |
| Archivo final (480p, 9:16, duración) | unverified | |

Veredictos: pass / revise / unverified / not_applicable. Cambiar cada valor solo tras inspección.

- Defectos observados (tiempo o región → observación → consecuencia → corrección mínima → qué se conserva):
- Preferencias estéticas separadas de defectos:
- Hipótesis sobre atención/deseo, sin validar:
- Elementos aceptados que deben conservarse:
- Reparación propuesta y si cabe en el alcance:
- Estado final y pendientes:
- Métricas reales, fuente y ventana, si existen:
