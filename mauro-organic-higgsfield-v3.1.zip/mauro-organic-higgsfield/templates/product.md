# Ficha de producto (V3.1)

Un solo registro canónico por producto (AI Prompt System §16, Content Factory §12).
Completar con hechos y fuentes; desconocido no significa falso ni autoriza inventar.
No enviar esta plantilla vacía al generador: al prompt van solo PRODUCT LOCK, LIGHT
BEHAVIOR LOCK, ancla de escala y el entorno de la escena.

- ID / nombre / aliases / variante activa:
- Revisión y fecha:
- Fuentes reales y fecha (ficha del proveedor, fotos, video de competidor, lo que Mauro dijo):
- Referencias aprobadas en Higgsfield (producto, caja, logo, avatares 4K por job_id; IDs rechazados por modelo):
- PRODUCT LOCK verbatim (forma, colores, acabado, cada parte contada, texto físico):
- Medidas y material confirmados con fuente; NO CONFIRMADOS:
- Ancla de escala (objeto de comparación; contra el cuerpo de quien lo sostiene; dónde va y dónde NUNCA va):
- Funcionamiento (preparación, operación, resultado, límites; qué contiene la caja en cada tipo de historia):
- LIGHT BEHAVIOR LOCK, si emite luz (dónde aterriza, color, caída, radio del rebote):
- Packaging e incluidos; excluidos de las tomas:
- Desgaste obligatorio en stills UGC (huella, raspón, polvo):
- Beneficios demostrados / afirmaciones pendientes, separados:
- Comprador, usuario y destinatario, por poder adquisitivo (del market research):
- Deseos, dudas y alternativas (citas del research, etiquetadas observación/hipótesis):
- Entornos ICP (mínimo cinco, distintos, del market research; el ancla de campaña marcado):
- Avatares del producto (chica y chico, 4K) y casting secundario:
- Ropa y temporada del mundo del producto:
- Reglas de uso real (dónde se usa el equipo y dónde no):
- Fórmula primaria (Content Factory §10) y trojan retail:
- Vocabulario de la tribu:
- Ángulos descartados / patrón validado (prompt que funcionó, job IDs, motivos):
