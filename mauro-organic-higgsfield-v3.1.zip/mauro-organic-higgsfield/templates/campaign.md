# Variables de campaña (V3.1)

AI Prompt System §17 y Content Factory §13. Se declaran una vez y se mantienen;
un cambio explícito de Mauro manda sobre lo guardado. No duplica la ficha.

- ID / revisión / fecha:
- Producto / variante y referencia a la ficha:
- MERCADO / IDIOMA (default Estados Unidos, inglés americano, señas §9.2):
- Público o situación prioritaria y evidencia:
- INTENCIÓN y emoción principal / secundaria (Content Factory §2):
- CASTING REGION:
- AVATARES recurrentes (identity locks + job IDs 4K; IDs rechazados por modelo):
- Vestuario de la tribu; HANDS & JEWELRY (default ON: manos cuidadas, uñas pintadas brillantes, pulsera dorada):
- SIGNATURE ENVIRONMENT y cambios permitidos:
- OVERLAY ZONE (default arriba):
- Sonido / diálogo; música y rótulos generados desactivados:
- BATCH SIZE (videos: exactamente los pedidos · prompts de imagen: número de Mauro, default 10):
- VIDEO DEFAULTS (9:16 · 480p · seedance_2_5 omni_reference · duración por video):
- IMAGE DEFAULTS (9:16 · 2K · nano_banana_2; gpt_image_2_5 para packaging/tipografía):
- Mapa PRESERVAR / CAMBIAR / EXCLUIR por cada referencia usada:
- Alcance autorizado (jobs, cantidades, reintentos):
- Últimas decisiones explícitas de Mauro y su fecha:
